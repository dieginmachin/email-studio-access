# Install Email Studio

## Claude Code (about 5 minutes)

**You need:** Claude Code on a paid Claude plan, Python 3, and Node 18+ (for brand extraction). Check with `python3 --version` and `node --version`.

1. **Put the plugin folder somewhere permanent**, for example `~/email-studio-plugin/` (the folder that holds this file and `.claude-plugin/`).
2. **Add it as a marketplace and install.** In Claude Code:
   ```
   /plugin marketplace add ~/email-studio-plugin
   /plugin install email-studio@email-studio
   ```
   Restart Claude Code.
3. **Check it.** Type `/email-studio:` and you should see `new-brand`, `plan-week`, `run-week`, `run-queue`, `sync`. Ask "what are the Email Studio stages?" and Claude should answer from the `studio` skill.
4. **Connect your tools** (claude.ai → Settings → Connectors; they show up in Claude Code too): **Figma**, plus **Asana** or **ClickUp**, whichever holds your briefs. In Figma desktop, have edit access to the brand's email files and the Emailify plugin installed.
5. **Make a working folder** for your brands and open Claude Code in it:
   ```bash
   mkdir -p ~/email-studio-work && cd ~/email-studio-work && claude
   ```
   Then: `/email-studio:new-brand <Brand name>`.

**Try it first on the sample brand:** copy `samples/fernhill-outfitters/` into `~/email-studio-work/brands/fernhill/` and ask "plan the week for Fernhill from its week.json" or "show me what brand-extract made for Fernhill". Fernhill is made up.

**First brand extraction:** `brand-extract` runs `npx --yes dembrandt <url>`. The first run downloads dembrandt. If it says no browser is installed, run `npx playwright install chromium` once.

**Update later:** replace the plugin folder with the new version, then `/plugin marketplace update email-studio` and restart.

## Claude app (claude.ai or desktop)

The app runs the same skills one at a time, from the zips in `app-skills/`. There are no agents or slash commands in the app, and no shared folder between chats: attach the brand's `BRAND.md` and `library.json` when a skill needs them, and save the files Claude gives back.

1. In Settings, turn on code execution and skills (under Capabilities; the exact menu names can change).
2. Under Skills, upload a zip from `app-skills/`. One zip per skill; upload the ones you'll use. Start with:
   - `studio.zip` (routes you to the rest)
   - `brand-extract.zip`, `rules-sweep.zip`, `feedback-twice.zip` (Stage 2)
   - `preflight.zip` (Stage 8)
3. New chat. Say what you want ("review this email against our rules"). Claude picks the skill from its description.

What works where:
| Skill | In the Claude app |
|---|---|
| `brand-extract` | The app can't run `npx`. Run `npx dembrandt <url> --save-output` on your computer and attach the JSON from `output/<domain>/`. |
| `feedback-twice`, `preflight`, `email-layers`, `model-review-team`, `studio-ops-team`, `capacity-calculator` | Work from attached files (CSV, JSON, screenshots, exports). With the Figma connector they read frames directly. |
| `library-digest`, `atomic-emails`, `figma-reshuffle-build`, `review-deck` | Need the Figma connector. |
| `intake-sort`, `week-planner` | Need the Asana or ClickUp connector, or an attached CSV. |
| `run-queue`, `approval-sync` | Need a review hub; not included. Skip them. |

## Check the scripts
Every script runs with Python 3 and no extra packages. The tests that ran when this version was built are listed in `MANIFEST.md` and `test-results.json`, next to this plugin folder.
