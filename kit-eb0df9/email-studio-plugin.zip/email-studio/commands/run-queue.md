---
description: Work a review hub's job queue once (Stage 9 · Run). Only for brands with a hub on BRAND.md's Hub line
---
Run the `run-queue` skill against the brand's review hub: heartbeat, pick queued jobs oldest first, run the stages, write progress back. Stop before anything goes to the client. If no brand has a `Hub:` line, say so and suggest `/email-studio:run-week` instead.
