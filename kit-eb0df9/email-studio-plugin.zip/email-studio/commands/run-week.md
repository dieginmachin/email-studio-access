---
description: Run the studio for one brand and week (Stages 1 to 8): sort, sweep, pick, build, preflight, review deck
---
Run the studio for $ARGUMENTS (brand and Monday date). Use the studio-lead agent and this order: intake-sort → rules-sweep → copy-template-match → precedent-picker → figma-reshuffle-build → preflight → review-deck. If the brand has a hub on BRAND.md's `Hub:` line, update it. Stop before anything goes to the client: a human reviews the deck first.
