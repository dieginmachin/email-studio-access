---
description: Apply review hub approvals in Figma (Stage 9 · Run). Only for brands with a hub on BRAND.md's Hub line
---
Run `approval-sync`: read reviews and jobs from the brand's hub, apply them in Figma, report what moved. Without a hub, review happens in the Figma deck from `review-deck`.
