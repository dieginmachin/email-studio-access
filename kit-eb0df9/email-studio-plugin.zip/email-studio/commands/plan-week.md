---
description: Plan next week for a brand (Stage 1 · Intake and Stage 9 · Run): sort briefs, pick precedents, list client questions
---
Load the `studio` skill, then run `week-planner` for $ARGUMENTS (brand and Monday date, or every brand in `brands/`). Draft the client questions; send nothing.
