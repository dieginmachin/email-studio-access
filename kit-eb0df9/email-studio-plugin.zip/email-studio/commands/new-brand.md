---
description: Start a new brand (Stages 2 to 5): brand extraction, The Rules File, Figma page, library digest, rules sweep, layers audit
---
Onboard the brand $ARGUMENTS. Load the `studio` skill first. Work in the current folder; the brand's files go in `brands/<brand-slug>/`.
1. Ask for anything missing, in one message: brand name, website, Figma file key(s) with approved emails (this year and last), PM tool (Asana or ClickUp) and project or list id, the field that holds the real status, who approves.
2. Stage 2 · Brand: run `brand-extract` on the website. It writes `brands/<slug>/BRAND.md` from The Rules File template (`${CLAUDE_PLUGIN_ROOT}/skills/brand-extract/templates/BRAND.md`) with the extracted style guide and proposed rules. Fill in the files, PM and reviewer lines.
3. In the brand's current Figma file, create ONE page named `🤖 Email Studio · <Brand>` (load figma-use first). Never a page per run.
4. Stage 3 · Library: run `library-digest` → `brands/<slug>/library.json` and `ledger.json`.
5. Stage 2 · Brand: run `rules-sweep` → the client's rules into BRAND.md under Hard / Soft, with who and when. Proposed rules wait for a human yes.
6. Stage 4 · Layers: run `email-layers` on two or three approved emails and report what doesn't follow Email Layers. Change nothing.
7. Report: emails digested, rules found, proposed rules waiting for a yes, layer findings, open questions for the client, and the suggested first `/email-studio:plan-week <brand> <monday>`.
Never post to the client. Keep `brands/` out of any public repo: it holds client data.
