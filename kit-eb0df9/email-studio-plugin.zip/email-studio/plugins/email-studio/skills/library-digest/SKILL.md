---
name: library-digest
description: Digest a brand's approved emails in Figma into a template library: row sequence, hero signature, module family, product capacity, last-used date. Use for a new brand, weekly refresh, or 'digest the library'.
---

# Library digest
1. List every 600-wide email frame named `YYMMDD (BRAND) Title` on the brand page and the exports page (2026 file) plus last year's file.
2. Per email: row families (IMG, TXT, SPLIT, GRID, TRIO, PAIR, DOUBLE, letter, sale), hero signature (logo-on-photo, framed white, panel colour, full-bleed), fonts, fills, button style, height.
3. Write `brands/<brand>/library.json` (one entry per approved email: id, name, mods, prod range, last, fits) and `ledger.json` (send log).
Script: `scripts/figma/digest.js`. Manual: Ch. 02 Templates first, Ch. 04 Atomic Emails. Team: 04 Atomic.
