---
name: copy-template-match
description: Parse a brief's copy (Asana form passthrough or a ClickUp structured copy doc with --- SECTION --- blocks) into sections and slots, and match it to the brand's approved templates with reasons and a copy→row slot map. Use for 'match this brief', ClickUp feeds, or before a build.
---

# Copy-template match
Parser: subject, preview, template named, sections (headline, subheadline, text, CTAs, repeated blocks), product links, letter / sale / grid signals.
Classify: letter · sale · reviews · single product · grid · multi-product · message-led.
Score each library template: named +100, kind match, product capacity, recent use −25 (<21 days), fresh +8 (>90 days). Top 3 with reasons, then a slot map (copy line → row). Same logic runs live in the hub's ClickUp view; "Ask Claude to refine" returns rows + client questions.
Brands without a library → queue a digest first.
