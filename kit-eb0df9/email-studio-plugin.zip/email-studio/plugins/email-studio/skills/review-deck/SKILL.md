---
name: review-deck
description: Group each email into its own Figma section and build a Present-mode review deck (1920×1080 slides, scrollable email, brief, why, flags, ← → keys). Use when Diego reviews in Figma or says 'make it easy to navigate'.
---

# Review deck
1. Per email: one sub-section `<Day date · slot> · <Title>` holding brief | email | card.
2. Deck section above the page: cover, one slide per email (export the email at 600 wide into a vertical-scroll frame), summary slide.
3. Prototype: ON_KEY_DOWN 39/37 and Prev/Next buttons, flow starting point on the cover. Diego selects the cover and presses Present.
Script: `scripts/figma/review-deck.js`.
