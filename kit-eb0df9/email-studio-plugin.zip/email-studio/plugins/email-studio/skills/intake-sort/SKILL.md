---
name: intake-sort
description: Read briefs from Asana or ClickUp, sort them by the Status field (not the column), and flag missing fields, date conflicts and AI images. Use when Diego says 'sort the board', 'what's ready this week', 'run intake' or names a PD/DFY list.
---

# Intake + sort
Inputs: PM source (Asana project, ClickUp list or view), week.
1. Pull open tasks with due dates in the week (Asana `get_tasks` with `completed_since=now`; ClickUp `clickup_filter_tasks` with `list_ids` or `view_id`).
2. Read each brief: Asana `notes`; ClickUp: the "Copy interno" Doc page linked in the description (`clickup_get_document_pages`). The `ClickUp Task Link` custom field holds the Asana source URL: use it to join the two.
3. Sort by readiness: designed · ready (Status = Ok To Design, subject + preview present) · template named · missing info · conflicts (send date in the brief ≠ due date, hour mismatch, duplicated subject).
4. Write `brands/<brand>/weeks/<monday>.json` and post nothing to the client without Diego's OK.
Manual: Ch. 12 Brief to Klaviyo, Ch. 06 Template Prepping. Team: 02 Studio Ops.
