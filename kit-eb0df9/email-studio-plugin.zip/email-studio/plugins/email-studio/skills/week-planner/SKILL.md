---
name: week-planner
description: Plan the coming week before Monday: pull the week from Asana/ClickUp, sort readiness, assign precedents, list client questions, and lay the week map. Use Fridays or when Diego says 'plan next week', 'pre-week'.
---

# Week planner
Runs intake-sort → rules-sweep → precedent-picker for every send in the week; writes the week plan; seeds the hub map; drafts one message per client with the open questions (never sent without OK). Suggested schedule: Friday 10:00 for the next week, Monday 07:00 refresh.
Manual: Ch. 13 Capacity math and Black Friday.
