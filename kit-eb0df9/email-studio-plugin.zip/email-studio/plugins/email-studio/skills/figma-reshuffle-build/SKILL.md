---
name: figma-reshuffle-build
description: Build or remix an email in Figma by duplicating approved rows only: reorder, resize, flip, swap copy and photos. Use for 'build', 'remix', 'run the queue', or a queued job from the hub.
---

# Figma reshuffle build
File: the brand's current-year file. Page: `🤖 Email Studio · <Brand>` (never a new page). Sections: 🟡 In review (one sub-section per email: brief | email | card) · ✅ Approved · 🗄 Superseded.
1. Clone the precedent email frame (keeps Emailify data) or approved rows from other emails in the same file.
2. Copy: brief only; product names from the linked page. Fonts: the brand's hard rule. Buttons and footer as approved.
3. Photos: Shopify `/products/<handle>.json`, the linked variant's `image_id` for flats; on-model only in the linked colour, else a material close-up of that colour.
4. Hero layouts from older files: rebuild layer by layer inside this year's 📷 Image (scripts/figma/hero-replicate.js); never leave work in old files.
5. Finishing pass (learned from designer revisions; do this before preflight):
   - Hero title is styled, not just placed. Read the hero photo first: put the title in its empty space (sky, wall, open table), not in a separate text block under it. Use the brand's past hero title treatment from BRAND.md (for example two weights, first word Bold, rest Light, tight tracking; vertical along the edge when the photo is tall and the open space is a side strip). Align the title to the composition (right-aligned when the open space is right).
   - Hero colour block, when used, takes a colour from the hero photo (for example a blue taken from a jacket), never black unless BRAND.md allows it.
   - Crop every model photo on the person: face and full garment in frame, little dead background; lifestyle tiles may grow taller to fit the model.
   - Pair each product flat with the lifestyle photo of the same garment and colour in the same row (cream jogger flat next to the cream jogger photo).
   - Size product flats to fill their tile; no large white margins.
6. New version → old frame to Superseded, name carries the version.
7. When a human revises a build: diff it against the build (layer dump + side-by-side), log what changed in brands/<brand>/REVISIONS.md, and promote anything repeated into BRAND.md.
Scripts: `clone-rows.js`, `hero-replicate.js`, `upload-variant-images.py`. Manual: Ch. 03 Email Layers + Email Layers 2025 workshop.
