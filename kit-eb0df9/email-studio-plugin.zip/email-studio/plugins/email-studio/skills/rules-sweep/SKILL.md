---
name: rules-sweep
description: Collect the client's latest hard and soft rules from proofing notes, comments and client-edited Figma frames before any build. Use before every run, or when Diego says 'check the rules', 'latest feedback', 'patch notes'.
---

# Rules sweep
1. Asana: subtasks created as image annotations + comments on tasks in Feedback / Requires Edits / Completed, last 30 days.
2. Figma: frames the client edited ("i made these edits", "I designed this in Figma") are the newest spec; read type, spacing and buttons from them.
3. Write rules to `brands/<brand>/BRAND.md` under Hard (blocks export) or Soft (warns), each with who and when. A note that repeats becomes Hard (Brand Patch Notes).
Always-on rules for every brand: no new elements · brief copy only · website is the source · footers never change. Brand rules live only in the local `brands/<brand>/BRAND.md`.
Manual: Ch. 09 Brand context files + Patch Notes. Team: 01 Heuristics. Free skill: Feedback Twice.
