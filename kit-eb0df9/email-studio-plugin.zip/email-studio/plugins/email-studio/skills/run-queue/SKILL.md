---
name: run-queue
description: Work the Email Studio hub queue: pick up queued build, remix, plan-week and digest jobs oldest first, run the skills in order, and write each stage's progress, failures and the Figma link back to the hub. Use for "run the queue", the 15-minute scheduled runner, or when the hub's Run queue now button was pressed.
---

# Run queue (the runner)

Hub: the `Hub:` line in `brands/<brand>/BRAND.md` (a brand without one has no hub; review in the Figma deck instead). Read and write it with the ArtifactData tool (`url` = the hub).

## Each run (cheap when idle)
If there are no queued jobs and no new kick, write the heartbeat and stop. Don't read briefs, Figma or BRAND files on an idle run.

1. **Heartbeat.** `set` `runner/status` = `{at: now, state: "idle", host: "<machine>"}`. Read `runner/kick` too; a kick newer than the last run means someone pressed Run queue now.
2. **Pick.** `query` `jobs` where `status == "queued"`, oldest `at` first. Take one job at a time. If none, stop after the heartbeat.
3. **Claim.** `update` the job `{status: "running", started_at: now}` pinned with `if_version`. If the pin fails, someone else took it: skip it.
4. **Run the stages in order** for `build` and `remix` jobs, and record each one before and after:
   `intake-sort → rules-sweep → precedent-picker → figma-reshuffle-build → preflight → review-deck`.
   Before a stage: `update` `{stage: "<skill>", "stages": {..., "<skill>": {state: "running", at: now}}}` and `runner/status` `{state: "running", job, stage}`.
   After it: `{state: "done", at: now, note: "<one line: what it decided>"}`.
   `plan-week` jobs run `week-planner` only; `digest` jobs run `library-digest` only. `ping` jobs are health checks: mark `intake-sort` done with note "runner alive" and finish the job as done; no Figma, no PM tools.
5. **Finish.** `update` `{status: "done", done_at: now, fig: "<figma node url>", verdict: "<preflight verdict>"}`. Set `runner/status` back to idle.
6. **Fail cleanly.** On any error: `{status: "failed", error: "<what went wrong and what fixes it, one sentence>", stages.<skill>.state: "failed"}`. Never leave a job `running`. The hub shows Retry, which sets it back to `queued` with `attempts + 1`; stop retrying a job after 3 attempts and say so in `error`.

## Rules
- Stop before posting anything to the client or commenting on Asana/ClickUp tasks.
- Writes are pinned with `if_version`; re-read and redo only the failed write.
- Hard rules from `brands/<brand>/BRAND.md` beat everything except a template named in the brief. A hard-rule failure ends the job as `done` with verdict NOT_READY, not as `failed`.
- `figma-reshuffle-build` is the only email builder. Never use design-to-code or any web builder for an email.

## Schedule
Runs every 15 minutes as a scheduled Claude Code task on Diego's Mac (created only after Diego approves it). By hand: `/email-studio:run-queue`.
