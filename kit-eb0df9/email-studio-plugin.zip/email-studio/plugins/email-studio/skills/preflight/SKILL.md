---
name: preflight
description: Run hard and soft rule checks plus the 7-point pre-export checklist on a built email and write its decision card. Use after every build or remix, or 'preflight', 'check it'.
---

# Preflight
Hard (block): Email Layers hierarchy · fonts per brand rule · images only from linked products (no template leftovers) · copy = brief + product names · prices match · footer untouched · links set (Emailify, manual).
Soft (warn): rhythm vs neighbours · model in linked colour · whole garment · not too much.
7-point (Ch. 08): mobile stack, dark mode, Gmail clip, alt text, links tested, padding on Spacers, saved as template.
## Row provenance (every row on the card gets one label)
- **Observed**: exact copy of an approved row (same file or last year's).
- **Inferred**: an approved row reshuffled: flipped, resized, reordered, or a hero replicated layer by layer.
- **Substituted**: same row, photo or copy swapped (brief copy, linked variant photo, Charcoal close-up fallback).
- **No label = new element**: fails reshuffle-only. Verdict is NOT READY.

## Verdict (replaces pass/fail; the hub shows it next to Approve with the reviewer's name)
- **NOT READY**: any unlabeled row, any hard-rule failure (font, footer, foreign image, off-brief copy), or an open blocker (e.g. AI hero awaiting client approval).
- **UNVERIFIED**: no blockers, but evidence is missing: links not checked in Emailify, or the HTML export not compared to the Figma frame at 600px.
- **READY WITH SUBSTITUTIONS**: all gates and evidence pass; Substituted rows remain and are listed.
- **READY**: all gates and evidence pass with Observed/Inferred rows only.
Order of precedence: NOT READY > UNVERIFIED > READY WITH SUBSTITUTIONS > READY. Never call an UNVERIFIED email ready.

## Optional render diff
Export the email from Emailify as HTML, render it at 600px, screenshot it, and compare with the Figma frame export at 600px. Fix and re-compare up to two times. Export drift (e.g. a 2025 footer) is a hard failure. When it matches, tick "HTML export matches" on the hub (collection `evidence/<emailId>`).

Writes the "Why this design" card: built-from thumbnails, rhythm strip, decisions, chapter chips. Script: `scripts/figma/decision-card.js`, `preflight.js`.
