---
name: precedent-picker
description: Choose the approved precedent for each brief: named template, last year's matching send for sale sets, letter for founder notes, the client grid when a grid is requested, otherwise a hero and module unused in the last 8 sends. Use when planning or before building.
---

# Precedent picker
Order of authority: brief names a template → use it (rotation off). Sale / BFCM → last year's matching send in the set, vary hero and module across the set. Letter → approved founder letter. "Feature in a grid" → client tile grid. Else: hero ≠ the 3 sends before and 2 after; module unused for 8 sends; never 3 identical rows in a row; body ground alternates with the previous send.
Black bodies only for BFCM with precedent. No new elements, ever.
Output: precedent id + reasons, written into the week plan and the decision card.
Manual: Ch. 05 Template Remix 625.
