---
description: Sync hub approvals and run the studio queue
---
Run approval-sync: read reviews and jobs from the hub, apply them in Figma, report what moved.
