---
description: Work the Email Studio hub queue once (what the 15-minute runner does)
---
Run the run-queue skill against the hub: heartbeat, pick queued jobs oldest first, run the stages, write progress back. Stop before anything goes to the client.
