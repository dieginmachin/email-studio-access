---
description: Set up a new brand in the Email Studio (BRAND.md, Figma page, library digest, rules sweep)
---
Onboard the brand $ARGUMENTS. Work inside the email-studio repo folder.
1. Ask for anything missing, in one message: brand name, Figma file key(s) with approved emails (this year and last), PM tool and project/list id, the status field to sort by, website, who approves.
2. Copy `brands/_template/BRAND.md` to `brands/<brand-slug>/BRAND.md` and fill it in.
3. In the brand's current Figma file, create ONE page named `🤖 Email Studio · <Brand>` (load figma-use first). Never make a page per run.
4. Run library-digest for the brand → `brands/<slug>/library.json` and `ledger.json`.
5. Run rules-sweep → add the client's rules to BRAND.md under Hard / Soft with who and when.
6. Report: emails digested, hard rules found, open questions for the client, and the suggested first `/email-studio:run-week <brand> <week>`.
Never post to the client. The brand folder is local only (git-ignored): never commit it. Leave the `Hub:` line empty unless Diego gives a hub link; without one, review happens in the Figma review deck.
