---
description: Run the Email Studio for one brand and week (sort, sweep, pick, build, preflight, deck)
---
Run the studio for $ARGUMENTS (brand and week). Use the studio-lead agent: intake-sort → rules-sweep → precedent-picker → figma-reshuffle-build → preflight → review-deck. Update the hub. Stop before posting anything to the client.
