---
description: Pre-week organizer for the next week
---
Run week-planner for $ARGUMENTS (brand, or all DFY lists).
