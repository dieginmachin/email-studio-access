# Figma scripts (use_figma)
Reference snippets proven in a live client run. Paste into `use_figma` after loading figma-use.
- `consolidate-page.js`: one page per brand with In review / Approved / Superseded sections.
- `hero-replicate.js`: serialize a hero in an old file (transform-relative leaves) and rebuild it inside this year's 📷 Image.
- `decision-card.js`: "Why this design" card with built-from thumbnails (exportAsync → createImage), rhythm strip, decisions, chapter chips.
- `review-deck.js`: per-email sections + 1920×1080 Present-mode deck wired with ON_KEY_DOWN 37/39.
- `preflight.js`: layer hierarchy, fonts, foreign images, copy-vs-brief check.
Gotchas: fonts that aren't installed (Google Sans) → replace the text layer with a clone of an approved Google Sans Flex layer; never touch footers; image fills can stack (replace the whole fills array); sections need resizeWithoutConstraints.