# Figma helper scripts

Not shipped in Email Studio 1.0.0. The skills name these helpers, but this version doesn't include them:
`consolidate-page.js`, `hero-replicate.js`, `clone-rows.js`, `digest.js`, `decision-card.js`, `review-deck.js`, `preflight.js`, `upload-variant-images.py`.

Until they ship, Claude writes the `use_figma` code live. Load the `figma-use` skill first.

The one Figma script that is included is the Atomic Emails extractor: `skills/atomic-emails/scripts/extract.figma.js`.

Gotchas from live runs:
- A font that isn't installed: replace the text layer with a clone of an approved layer in an installed font.
- Never touch footers.
- Image fills can stack: replace the whole fills array.
- Sections need `resizeWithoutConstraints`.
