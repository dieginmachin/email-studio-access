# Email Studio: the process

The 9 stages the plugin runs for any brand. It holds no client data: each brand's rules, files and run notes live in your local `brands/<brand>/` folder (`BRAND.md`, `library.json`, `ledger.json`, `weeks/`, `REVISIONS.md`). See `samples/fernhill-outfitters/` in the product folder for a made-up example.

A human approves every email. AI drafts.

## Where things live

| What | Where |
|---|---|
| Plugin (skills, agents, commands) | this folder |
| A brand's rules and library | local only: `brands/<brand>/` (created by `/email-studio:new-brand`) |
| Briefs | the brand's Asana project or ClickUp list (named in BRAND.md) |
| Approved emails | the brand's Figma file(s) (named in BRAND.md) |
| Studio output | ONE page per brand in its Figma file: `🤖 Email Studio · <Brand>`, with sections In review / Approved / Superseded. Never a page per run. |

## The 9 stages

| # | Stage | Skills | Agent |
|---|---|---|---|
| 1 | Intake | `intake-sort`, `week-planner` | sorter |
| 2 | Brand | `brand-extract`, `rules-sweep`, `feedback-twice` | librarian |
| 3 | Library | `library-digest` | librarian |
| 4 | Layers | `email-layers` | reviewer |
| 5 | Atomic | `atomic-emails` | librarian |
| 6 | Match + Remix | `copy-template-match`, `precedent-picker` | sorter, maker |
| 7 | Build | `figma-reshuffle-build` | maker |
| 8 | Review | `preflight`, `review-deck`, `model-review-team` | reviewer |
| 9 | Run | `studio-ops-team`, `capacity-calculator`, `run-queue`, `approval-sync` | studio-lead |

## 1 · Intake
Read every open brief. Sort by the brief's real status field (named in BRAND.md), not the board column. Ready = copy and links present. Flag missing fields, date conflicts and AI images.

## 2 · Brand
Extract the brand's style from its website (`brand-extract`, using the dembrandt CLI) into BRAND.md. Before every run, sweep comments and client-edited frames into Hard rules (block export) and Soft rules (warn), each with who and when. Feedback that happens on two different designs becomes a draft rule; a human approves it.

## 3 · Library
List every approved email frame (`YYMMDD (BRAND) Title`). Record row families, hero signature, fonts, fills, buttons, height and last-used date into `library.json`, and the send log into `ledger.json`. The 5 to 10 most-followed emails become the law, once a human confirms them.

## 4 · Layers
Check approved emails against Email Layers: Email, Wrappers, Rows, Columns, Spacers, Image. Padding lives on Spacers, backgrounds on Email or Wrappers, columns stack on mobile, and every layer has a real name. Agents can't read Group 234.

## 5 · Atomic
Cut approved emails into organisms, molecules and atoms on a Parts page, after a reviewer reads the dry run and a human says yes. The source emails are never touched.

## 6 · Match + Remix
Brief copy only, verbatim. Product names from the linked product page. Match the brief's sections to template rows and output a copy → row slot map. A template named in the brief wins. Sale sets use last year's matching send. Founder notes use the letter. Otherwise: hero different from the 3 sends before and 2 after; module unused in the last 8 sends; never 3 identical rows in a row. Every pick has a one-line reason.

## 7 · Build
Clone the precedent email (keeps Emailify data) or approved rows from other emails in the same file. Never draw new elements. Allowed: duplicate, reorder, resize, flip, swap copy and photos. Photos come from the brand's website; on-model only in the linked colour. A new version moves the old frame to Superseded.

## 8 · Review
Preflight checks the hard and soft rules and the 7 point checklist. Every row is labeled **Observed**, **Inferred** or **Substituted**; an unlabeled row is a new element and fails. Verdict: **Not ready** beats **Unverified** beats **Ready with substitutions** beats **Ready**. Each email gets a Present-mode review deck. Model Review checks the checker: how often your AI review agrees with a human.

## 9 · Run
Plan the week on Friday, run it, and report where time goes with a source on every number. Measure capacity (unique designs per business day, for the team) before you change anything. Only after the reviewer's OK: set links in Emailify, export at 2x, post to the PM task, move the status. Never post to a client without that OK.

## Learn from revisions
When a designer edits a build, diff it against the build, log it in `brands/<brand>/REVISIONS.md`, and propose anything repeated as a rule for BRAND.md.
