---
name: rules-sweep
description: "Stage 2 · Brand. Collect a brand's latest hard and soft rules from proofing notes, task comments and client-edited Figma frames, and write them into The Rules File (brands/<brand>/BRAND.md) with who and when. Use before every run, or for 'check the rules', 'latest feedback', 'patch notes'."
---

# Rules sweep (Stage 2)
1. PM tool: annotation subtasks and comments on tasks in feedback, edits or completed states, last 30 days.
2. Figma: frames the client edited ("I made these edits", "I designed this in Figma") are the newest spec; read type, spacing and buttons from them.
3. Write rules to `brands/<brand>/BRAND.md` under **Hard** (blocks export) or **Soft** (warns), each with who and when.

## When a note becomes a rule (folded in from Feedback Twice and the rule-maker)
- Once is a comment. The same note on **two different designs** is a draft rule. Put the notes in a `design,note` CSV and run the `feedback-twice` skill to cluster them.
- Every rule gets a test: a value to check or a yes/no question ending in `?`. A rule you can't check is a wish.
- Hard only if breaking it should block delivery; everything else is Soft. A Soft rule that keeps failing in review moves to Hard (Brand Patch Notes).
- Keep the evidence (the notes, who, when). Show each draft and ask "Add this rule?". Never add one without a yes.

Always-on rules for every brand: no new elements · brief copy only · the website is the source for photos, names and colours · footers never change · no AI imagery without approval.
Brand rules live only in the local `brands/<brand>/BRAND.md`.
Manual: Ch. 09 Brand context files and Brand Patch Notes.
