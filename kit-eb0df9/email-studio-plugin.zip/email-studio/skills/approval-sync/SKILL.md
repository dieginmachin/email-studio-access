---
name: approval-sync
description: "Stage 9 · Run. Optional, needs a review hub (not included). Read the hub's approvals and job queue and apply them in Figma and the PM tool: approved → ✅ Approved section, changes → new version via remix, plan-week and build jobs → run. Use for 'sync approvals', 'run the queue'."
---

# Approval sync
Hub: the `Hub:` line in `brands/<brand>/BRAND.md` (a brand without one has no hub; review in the Figma deck instead). Collections: `reviews/<emailId>` {decision, note, version}, `jobs/<auto>` {type: remix|build|plan-week|digest, target, mode, note, status}.
1. ArtifactData list `reviews`, `evidence` and `jobs`. A review carries `verdict` and `by` (reviewer id; resolve names with ArtifactData `profiles`).
   Approved with verdict NOT_READY: move it, but list it in the report as approved against the preflight.
2. Approved at the current version → move the email's sub-section into ✅ Approved. Changes → remix job with the note.
3. Run jobs oldest first; set status running → done (update the doc). Post a comment on the Asana/ClickUp task only after a human OKs posting.
4. Republish hub data (versions, images) when frames change.
