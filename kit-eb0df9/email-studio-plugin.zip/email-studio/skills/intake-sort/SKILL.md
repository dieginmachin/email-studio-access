---
name: intake-sort
description: "Stage 1 · Intake. Read email briefs from Asana or ClickUp, sort them by the real status field (not the board column), and flag missing fields, date conflicts and AI images. Use for 'sort the board', 'what's ready this week', 'run intake', or when someone names a brief list or project."
---

# Intake + sort (Stage 1)

Inputs: the brand's PM source (Asana project, ClickUp list or view, named in `brands/<brand>/BRAND.md`) and the week.

1. Pull open tasks with due dates in the week (Asana `get_tasks` with `completed_since=now`; ClickUp `clickup_filter_tasks` with `list_ids` or `view_id`).
2. Read each brief: Asana `notes`; ClickUp: the description, or the copy Doc page it links to (`clickup_get_document_pages`). If the team keeps a brief in both tools, use the field that holds the other tool's link to join them.
3. Sort by readiness: designed · ready (status says ready to design, subject and preview present) · template named · missing info · conflicts (send date in the brief ≠ due date, hour mismatch, duplicated subject).
4. Write `brands/<brand>/weeks/<monday>.json` (shape: `samples/fernhill-outfitters/week.json` in the product folder) and post nothing to the client without a human OK.

## Triage rules (from Studio Of One 02 Studio Ops)
- One task per email. Every known request gets a task, even with no copy yet.
- Priority: design due date first, send date second.
- A brief that can't start names the exact missing field. Draft the message that asks for it; don't send it.
- New brands start with a senior designer until 10 templates are approved.
- No number without a source: every count names the list and filter it came from.

No PM connector? Export the briefs as CSV and use `studio-ops-team` (its `ops.py triage` reads the same fields).
Manual: Ch. 12 Brief to Klaviyo, Ch. 06 Template Prepping.
