---
name: copy-template-match
description: "Stage 6 · Match + Remix. Parse a brief's copy (a PM form passthrough or a structured copy doc split into SECTION blocks) into sections and slots, and match it to the brand's approved templates with reasons and a copy → row slot map. Use for 'match this brief', or before a build."
---

# Copy-template match (Stage 6, P1 Match)
Parser: subject, preview, template named, sections (headline, subheadline, text, CTAs, repeated blocks), product links, letter / sale / grid signals.
Classify: letter · sale · reviews · single product · grid · multi-product · message-led.
Score each template in `brands/<brand>/library.json`: named in the brief +100, kind match, product capacity fits, used in the last 21 days −25, unused for 90 days +8. Show the top 3 with reasons, then a slot map (copy line → row).
Copy is the brief's, verbatim. Product names come from the linked product page. No descriptions unless the brief writes them.
Brands without a library: run `library-digest` first.
Manual: Ch. 06 Template Prepping System.
