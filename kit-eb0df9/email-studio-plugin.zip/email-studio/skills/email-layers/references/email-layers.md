# Email Layers (Capacity Manual, chapter 03)

Open a teammate's Figma file and you should feel at home. Every email file uses the same six layers, nested in the same order.

| # | Layer | What it is |
|---|---|---|
| 1 | Email | The whole message. The outer frame. |
| 2 | Wrappers | Full-width bands that group a section and carry its background. |
| 3 | Rows | Horizontal slices inside a wrapper. |
| 4 | Columns | Vertical splits inside a row. |
| 5 | Spacers | Empty layers that hold padding, by rule. |
| 6 | Image | Image layers, named as images. |

## The four rules
1. **Padding lives on Spacers.** Never on a text box, never as auto layout padding hidden inside a row.
2. **Backgrounds live on Email or Wrappers.** A coloured band is a wrapper with a fill, not a rectangle behind a group.
3. **One font convention.** Headline, body and CTA each have one style. A fourth size becomes a rule first.
4. **Columns stack on mobile.** Build every column to stack; don't patch it at export.

Plus the naming principle: **agents can't read Group 234.** A file with predictable names is one Claude can read, check and comment on through Figma MCP.

## How the audit maps to them
| Check | Rule | Kind |
|---|---|---|
| L01 | The outer frame is the Email | hard |
| L02 | Email > Wrappers > Rows > Columns, in order | hard |
| L03 | Padding lives on Spacers | hard |
| L04 | Backgrounds live on Email or Wrappers | hard |
| L05 | Columns stack on mobile | hard |
| L06 | No default names (Group 234, Frame 12) | soft |
| L07 | Every name says which layer it is | soft, a question for a human |

The font convention needs the brand's type rule: `preflight` checks it against BRAND.md.
Emailify's own layer names (🎁 wrapper, 🚣 Row, 🏛️ Column, 📷 Image, 🔗 button) are recognised.

**Don't rename halfway.** Mixing old names and Email Layers in one file is worse than either. Convert the whole file at once, or start the next email clean.
