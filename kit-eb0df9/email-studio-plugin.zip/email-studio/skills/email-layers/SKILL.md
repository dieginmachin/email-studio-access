---
name: email-layers
description: "Stage 4 · Layers. Audit a Figma email against Email Layers (Email, Wrappers, Rows, Columns, Spacers, Image) so people and agents can read it: nesting order, padding only on Spacers, backgrounds only on Email or Wrappers, columns that stack, no 'Group 234' names. Reports with evidence and changes nothing. Use for 'audit the layers', 'is this file clean', 'check the layer names', before atomizing, or when onboarding a brand's Figma file."
---

# Email Layers audit (Stage 4)

From Capacity Manual chapter 03. **Agents can't read Group 234.** A file with predictable layers is one anyone, or any model, can pick up. The six layers and four rules are in `references/email-layers.md`.

## Workflow
1. **Get the email.** A Figma link plus which frames (one email, a page, or 2 or 3 approved emails for a new brand).
2. **Read it into a design JSON.** With the Figma connector: `create_session`, then `get_metadata` on each frame. Write `design.json` in the shape of `examples/design.json`: every layer's `name`, `type` (TEXT for text), `children`, any `padding` (or paddingTop / paddingBottom / paddingLeft / paddingRight), and `background` for layers that have their own fill. Record `checks.columns_stack` only if you looked at a phone width. Leave out what you couldn't read; it comes back as a question, never as a pass.
3. **Run the audit.** `python3 scripts/layers.py audit design.json` (add `--json` for a log). Exit code 1 means a hard rule failed.
4. **Stop at the human.** Show a table: rule · kind · status · evidence · suggested fix. Hard fails first. End with: "Nothing has been changed. Which of these should be fixed?"
5. **Fix only what they approve**, in Figma, with figma-use loaded. Never rename halfway through a file: convert the whole email or leave it.

## What it checks
L01 outer frame is the Email · L02 Email > Wrappers > Rows > Columns · L03 padding only on Spacers · L04 backgrounds only on Email or Wrappers · L05 columns stack on mobile · L06 no default names · L07 every name maps to one of the layers (a question when it doesn't).

Next stage: `atomic-emails` (clean layers map straight to parts: wrappers → organisms, rows and columns → molecules, text and images → atoms).
