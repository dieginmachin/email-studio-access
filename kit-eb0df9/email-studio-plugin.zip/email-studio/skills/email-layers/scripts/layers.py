"""Email Layers audit: check an email's layer tree against the six layers and their rules.

Usage:
  python3 layers.py audit design.json [--json]

design.json is the same shape the preflight skill uses: {"name", "checks": {...}, "layers": [{"name", "type"?,
"padding"?, "background"?, "role"?, "children": [...]}]}. Build it from Figma MCP (get_metadata /
get_design_context) or by hand. A field you couldn't read is left out and comes back as needs-human, never as a pass.

The six layers, in order: Email > Wrappers > Rows > Columns, with Spacers and Image inside.
Rules (Capacity Manual ch. 03): padding lives on Spacers; backgrounds live on Email or Wrappers;
columns stack on mobile; every layer has a name a stranger (or a model) can follow.
Python 3, no dependencies. It reads; it never changes the file.
"""
import json, re, sys
from pathlib import Path

RANK = {"email": 0, "wrapper": 1, "row": 2, "column": 3}
PATTERNS = [  # order matters: first match wins
    ("spacer", re.compile(r"spacer|↕", re.I)),
    ("wrapper", re.compile(r"wrapper|🎁", re.I)),
    ("column", re.compile(r"\bcol(umn)?s?\b|🏛", re.I)),
    ("row", re.compile(r"\brows?\b|🚣", re.I)),
    ("image", re.compile(r"\b(image|img|photo|picture)\b|📷", re.I)),
    ("email", re.compile(r"^\s*(📧\s*)?email\b|^\d{6} \(", re.I)),
    ("atom", re.compile(r"button|cta|🔗|logo|headline|heading|title|body|copy|text|caption|badge|icon|social|divider|link|price|label|footer|header|nav", re.I)),
]
DEFAULT = re.compile(r"^(group|frame|rectangle|ellipse|vector|layer|line|component|instance|polygon|star|union|subtract)\s*\d*$|^(image|text)\s+\d+$", re.I)
BG_OK = {"email", "wrapper"}


def role(layer, depth):
    if layer.get("role") in RANK or layer.get("role") in ("spacer", "image", "atom"):
        return layer["role"]
    name = (layer.get("name") or "").strip()
    if (layer.get("type") or "").upper() == "TEXT":
        return "atom"
    if DEFAULT.match(name):
        return "default"
    for r, pat in PATTERNS:
        if pat.search(name):
            return r
    if depth == 0:
        return "email" if re.search(r"email", name, re.I) else "unknown"
    return "unknown"


def walk(layers, path="", depth=0, parent_rank=-1):
    for l in layers or []:
        p = f"{path}/{l.get('name', '?')}"
        r = role(l, depth)
        yield p, l, r, depth, parent_rank
        nr = RANK.get(r, parent_rank)
        yield from walk(l.get("children"), p, depth + 1, nr)


def padding_of(l):
    vals = [l.get(k) for k in ("padding", "paddingTop", "paddingBottom", "paddingLeft", "paddingRight")]
    return [v for v in vals if isinstance(v, (int, float)) and v > 0]


def audit(design):
    layers = design.get("layers") or []
    rows = list(walk(layers))
    out = []

    def add(rid, kind, statement, status, evidence):
        out.append({"rule": rid, "kind": kind, "statement": statement, "status": status, "evidence": evidence, "decision": "pending"})

    if not rows:
        add("L01", "hard", "The outer frame is the Email.", "needs-human", "no layers in the design file")
        return out

    tops = [(p, r) for p, l, r, d, _ in rows if d == 0]
    bad = [p for p, r in tops if r != "email"]
    add("L01", "hard", "The outer frame is the Email.", "fail" if bad else "pass",
        ("not named as the Email: " + ", ".join(bad)) if bad else f"{len(tops)} email frame(s)")

    bad = [f"{p} ({r} inside a {[k for k, v in RANK.items() if v == pr][0]})" for p, l, r, d, pr in rows
           if r in RANK and pr >= 0 and RANK[r] <= pr]
    add("L02", "hard", "Layers nest in order: Email > Wrappers > Rows > Columns.", "fail" if bad else "pass",
        "; ".join(bad[:6]) if bad else "nesting order holds")

    bad = [f"{p} = {padding_of(l)}" for p, l, r, d, pr in rows if r != "spacer" and padding_of(l)]
    add("L03", "hard", "Padding lives on Spacers.", "fail" if bad else "pass",
        "padding off a Spacer: " + "; ".join(bad[:6]) if bad else "padding only on Spacers")

    seen_bg = [x for x in rows if "background" in x[1]]
    bad = [f"{p} ({l['background']})" for p, l, r, d, pr in seen_bg if l.get("background") and r not in BG_OK and r != "atom"]
    if not seen_bg:
        add("L04", "hard", "Backgrounds live on Email or Wrappers.", "needs-human", "no background fields in the design file")
    else:
        add("L04", "hard", "Backgrounds live on Email or Wrappers.", "fail" if bad else "pass",
            "background on " + "; ".join(bad[:6]) if bad else "backgrounds only on Email or Wrappers")

    v = (design.get("checks") or {}).get("columns_stack")
    has_cols = any(r == "column" for _, _, r, _, _ in rows)
    if not has_cols:
        add("L05", "hard", "Columns stack on mobile.", "pass", "no columns")
    elif v is None:
        add("L05", "hard", "Columns stack on mobile.", "needs-human", "not recorded: columns_stack (check at phone width)")
    else:
        add("L05", "hard", "Columns stack on mobile.", "pass" if v else "fail", f"columns_stack = {v}")

    bad = [p for p, l, r, d, pr in rows if r == "default"]
    add("L06", "soft", "Every layer has a real name (agents can't read Group 234).", "fail" if bad else "pass",
        "default names: " + ", ".join(bad[:6]) if bad else "no default names")

    unk = [p for p, l, r, d, pr in rows if r == "unknown"]
    add("L07", "soft", "Every layer's name says which of the six layers it is (or that it's text, a button or a logo).",
        "needs-human" if unk else "pass", ("can't tell the layer from the name: " + ", ".join(unk[:6]) + ". Rename, or is it fine?") if unk else "every name maps to a layer")
    return out


def summary(findings):
    c = {s: sum(1 for f in findings if f["status"] == s) for s in ("pass", "fail", "needs-human")}
    return {"counts": c, "hard_fails": [f["rule"] for f in findings if f["status"] == "fail" and f["kind"] == "hard"],
            "note": "Audit only. Nothing was changed. A human decides what to rename or move."}


def main(a):
    if len(a) < 2 or a[0] != "audit":
        print(__doc__)
        return 2
    try:
        design = json.loads(Path(a[1]).read_text())
    except (OSError, ValueError) as e:
        print(f"Can't read {a[1]}: {e}", file=sys.stderr)
        return 2
    f = audit(design)
    s = summary(f)
    if "--json" in a:
        print(json.dumps({"findings": f, "summary": s}, indent=2, ensure_ascii=False))
    else:
        order = {"fail": 0, "needs-human": 1, "pass": 2}
        for x in sorted(f, key=lambda x: (order[x["status"]], x["kind"] != "hard")):
            print(f"{x['rule']} {x['kind']:<4} {x['status']:<11} {x['statement']}  [{x['evidence']}]")
        print(s["note"])
    return 1 if s["hard_fails"] else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
