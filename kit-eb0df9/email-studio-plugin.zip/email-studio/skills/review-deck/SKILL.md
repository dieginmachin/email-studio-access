---
name: review-deck
description: "Stage 8 · Review. Group each built email into its own Figma section and build a Present-mode review deck (1920×1080 slides, scrollable email, brief, why, flags, arrow keys). Use when a human reviews in Figma, after preflight, or for 'make it easy to review'."
---

# Review deck (Stage 8)
1. Per email: one sub-section `<Day date · slot> · <Title>` holding brief | email | decision card.
2. Deck section above the page: cover, one slide per email (export the email at 600 wide into a vertical-scroll frame) with its verdict, summary slide.
3. Prototype: ON_KEY_DOWN 39/37 and Prev/Next buttons, flow starting point on the cover. The reviewer selects the cover and presses Present.
Load figma-use first. Changes come back as notes; each one becomes a remix of that email.
