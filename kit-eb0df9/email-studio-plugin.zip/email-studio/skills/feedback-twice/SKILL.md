---
name: feedback-twice
description: Stage 2 · Brand. Free skill from Diego Garza's Studio Of One. Paste your review notes or client comments and it finds feedback that happened on two or more different designs, then drafts each one as a testable rule for you to approve. Use when someone says "we keep getting the same feedback", wants to turn comments into design rules, or asks what their clients keep asking for.
---

# Feedback Twice

**Feedback that happens twice is a rule you forgot to write.** Once is a comment. Twice, on two different designs, is a rule.

This is one agent from Team Nº 01 · Heuristics, working alone.

## Workflow
1. Put the notes in a CSV with `design,note` (one row per note, with the design it was about). If the person pastes loose text, build the CSV yourself and show it.
2. Run `python3 scripts/heuristics.py from-feedback notes.csv`.
3. Rewrite each draft as a short rule a new designer could follow on day one, and give it a test: a value to check or a yes/no question ending in `?`. A rule you can't check is a wish.
4. Run `python3 scripts/heuristics.py lint` on the drafts until it says every rule is testable.
5. Show each rule with the notes it came from and ask: "Add this rule?" Never add one without a yes.

Single comments stay comments. Don't promote them.

In Email Studio, `rules-sweep` collects the notes for you and `preflight` checks every email against the rules you approve.
