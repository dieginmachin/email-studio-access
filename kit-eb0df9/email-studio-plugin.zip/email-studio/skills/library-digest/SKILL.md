---
name: library-digest
description: "Stage 3 · Library. Digest a brand's approved emails in Figma into a template library: row sequence, hero signature, module family, product capacity, last-used date. Use for a new brand, a weekly refresh, or 'digest the library'."
---

# Library digest (Stage 3)
1. List every email-width frame (around 600 wide) named like `YYMMDD (BRAND) Title` on the brand's pages in this year's file, plus last year's file.
2. Per email: row families (IMG, TXT, SPLIT, GRID, TRIO, PAIR, DOUBLE, letter, sale), hero signature (logo-on-photo, framed white, panel colour, full-bleed), fonts, fills, button style, height.
3. Write `brands/<brand>/library.json` (one entry per approved email: id, name, mods, prod range, last, hero, fits) and `ledger.json` (send log). Shape: `samples/fernhill-outfitters/library.json`.
4. Templates first: mark the 5 to 10 emails the brand's other emails follow most (most reused rows, most recent approvals) as candidates for "the law", and ask the human to confirm them. Don't decide alone.

Load figma-use before any `use_figma` call. The Template Auto-Sorter (https://dieginmachin.github.io/template-auto-sorter/) sorts and names a template library in the browser.
Manual: Ch. 02 Templates first, Ch. 04 Atomic Emails.
