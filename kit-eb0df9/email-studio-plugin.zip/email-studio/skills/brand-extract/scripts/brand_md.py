"""Turn a dembrandt JSON extraction into a brand's BRAND.md (The Rules File + the extracted style guide).

Usage:
  python3 brand_md.py <dembrandt.json> --brand "Name" [--out brands/<slug>/BRAND.md] [--force]
  python3 brand_md.py <dembrandt.json> --brand "Name" --style-only [--out STYLE.md]
  python3 brand_md.py <dembrandt.json> --summary          # JSON summary, nothing written

Python 3, no dependencies. Every value comes from the extraction; nothing is invented.
Proposed rules are drafts: a human moves them into Hard or Soft.
"""
import argparse, json, re, sys
from collections import OrderedDict
from datetime import date
from pathlib import Path

HERE = Path(__file__).resolve().parent
TEMPLATE = HERE.parent / "templates" / "BRAND.md"


# ---------- helpers ----------
def to_hex(v):
    """'rgb(1, 2, 3)', 'rgba(1,2,3,0.5)', '#abc', '#aabbcc' -> '#aabbcc' (alpha dropped). Else None."""
    if not isinstance(v, str):
        return None
    s = v.strip().lower()
    m = re.match(r"^#([0-9a-f]{3}|[0-9a-f]{6})([0-9a-f]{2})?$", s)
    if m:
        h = m.group(1)
        return "#" + ("".join(c * 2 for c in h) if len(h) == 3 else h)
    m = re.match(r"^rgba?\(\s*(\d+)[,\s]+(\d+)[,\s]+(\d+)", s)
    if m:
        return "#" + "".join(f"{min(255, int(x)):02x}" for x in m.groups())
    m = re.search(r"#[0-9a-f]{6}", s)
    return m.group(0) if m else None


def px(v):
    if isinstance(v, (int, float)):
        return float(v)
    m = re.match(r"^\s*(-?\d+(?:\.\d+)?)\s*px", str(v or ""))
    return float(m.group(1)) if m else None


def fmt_px(v):
    n = px(v)
    if n is None:
        return str(v) if v not in (None, "") else "?"
    return f"{n:g}px" if abs(n - round(n)) < 0.01 or abs(n) >= 10 else f"{n:.1f}px"


def slug(s):
    return re.sub(r"[^a-z0-9]+", "-", (s or "brand").lower()).strip("-") or "brand"


# ---------- extract ----------
def summarize(d):
    out = OrderedDict()
    meta = d.get("meta") or {}
    out["url"] = d.get("url") or meta.get("requestedUrl") or ""
    out["site"] = d.get("siteName") or ""
    out["extracted_at"] = (d.get("extractedAt") or "")[:10]
    out["dembrandt"] = meta.get("dembrandtVersion") or ""

    c = d.get("colors") or {}
    sem = OrderedDict()
    for k, v in (c.get("semantic") or {}).items():
        h = to_hex(v)
        if h:
            sem[k] = h
    out["semantic"] = sem
    pal = []
    for p in c.get("palette") or []:
        h = p.get("normalized") or to_hex(p.get("color"))
        if h:
            pal.append({"hex": h.lower(), "role": p.get("role") or "", "count": p.get("count") or 0,
                        "confidence": p.get("confidence") or ""})
    pal.sort(key=lambda p: -p["count"])
    out["palette"] = pal[:12]
    out["css_vars"] = [{"name": k, "hex": (v.get("hex") if isinstance(v, dict) else to_hex(v))}
                       for k, v in list((c.get("cssVariables") or {}).items())[:16]]
    out["css_vars"] = [v for v in out["css_vars"] if v["hex"]]

    t = d.get("typography") or {}
    fam_count = OrderedDict()
    styles = []
    for s in t.get("styles") or []:
        fam = (s.get("family") or "").strip()
        if not fam:
            continue
        n = s.get("count") or 1
        fam_count[fam] = fam_count.get(fam, 0) + n
        styles.append({"context": s.get("context") or "", "family": fam, "size": fmt_px(s.get("size")),
                       "size_px": px(s.get("size")) or 0, "weight": s.get("weight"),
                       "line_height": s.get("lineHeight"), "tracking": s.get("spacing"),
                       "transform": s.get("transform"), "count": n})
    out["families"] = [f for f, _ in sorted(fam_count.items(), key=lambda kv: -kv[1])]
    seen, top = set(), []
    for s in sorted(styles, key=lambda s: (-s["count"], -s["size_px"])):
        key = (s["context"], s["family"], s["size"], s["weight"])
        if key not in seen:
            seen.add(key)
            top.append(s)
    out["type_styles"] = sorted(top[:10], key=lambda s: -s["size_px"])
    def top_family(match):
        tally = OrderedDict()
        for s in styles:
            if match(s["context"].lower()):
                tally[s["family"]] = tally.get(s["family"], 0) + s["count"]
        return max(tally, key=tally.get) if tally else None
    out["headline_family"] = top_family(lambda c: c.startswith(("display", "heading", "h1", "h2", "h3")))
    out["body_family"] = top_family(lambda c: c in ("body", "text", "paragraph"))
    src = t.get("sources") or {}
    out["google_fonts"] = list(src.get("googleFonts") or [])
    out["custom_fonts"] = list(src.get("customFonts") or [])

    sp = d.get("spacing") or {}
    out["spacing"] = [v.get("px") or v.get("display") for v in sorted(sp.get("commonValues") or [], key=lambda v: -(v.get("count") or 0))[:10]]
    out["spacing"] = sorted({s for s in out["spacing"] if s}, key=lambda s: px(s) or 0)
    out["radii"] = [v.get("value") for v in sorted((d.get("borderRadius") or {}).get("values") or [], key=lambda v: -(v.get("count") or 0))[:6] if v.get("value")]

    comp = d.get("components") or {}
    buttons = []
    for b in comp.get("buttons") or []:
        st = (b.get("states") or {}).get("default") or b
        hover = (b.get("states") or {}).get("hover") or {}
        buttons.append({"bg": to_hex(st.get("backgroundColor")), "text": to_hex(st.get("color")),
                        "radius": st.get("borderRadius"), "padding": st.get("padding"),
                        "font_size": st.get("fontSize"), "font_weight": st.get("fontWeight"),
                        "border": st.get("border"), "hover_bg": to_hex(hover.get("backgroundColor"))})
    out["buttons"] = buttons[:4]
    links = []
    for l in comp.get("links") or []:
        hv = (l.get("states") or {}).get("hover") or {}
        links.append({"color": to_hex(l.get("color")), "decoration": l.get("textDecoration"),
                      "hover_color": to_hex(hv.get("color")), "hover_decoration": hv.get("textDecoration")})
    out["links"] = links[:3]
    badges = (comp.get("badges") or {}).get("all") if isinstance(comp.get("badges"), dict) else comp.get("badges")
    out["badges"] = [{"bg": to_hex(b.get("backgroundColor")), "text": to_hex(b.get("color")), "radius": b.get("borderRadius")}
                     for b in (badges or [])[:3]]

    m = d.get("motion") or {}
    out["durations"] = [x.get("value") for x in sorted(m.get("durations") or [], key=lambda x: -(x.get("count") or 0))[:5] if x.get("value")]
    out["easings"] = [x.get("value") for x in sorted(m.get("easings") or [], key=lambda x: -(x.get("count") or 0))[:4] if x.get("value")]
    out["animations"] = [x.get("name") for x in (m.get("animations") or [])[:6] if x.get("name")]
    out["interactions"] = sorted({x.get("pattern") for x in m.get("interactiveDeltas") or [] if x.get("pattern")})

    out["breakpoints"] = [b.get("px") for b in d.get("breakpoints") or [] if b.get("px")]
    logo = d.get("logo") or {}
    out["logo"] = logo.get("url") if isinstance(logo.get("url"), str) and not logo.get("url", "").startswith("data:") else None
    return out


# ---------- write ----------
def proposed_rules(s, today):
    who = f"extracted from {s['url'] or 'the site'}, {today}; confirm with the client"
    rules = []
    if s["headline_family"] or s["body_family"]:
        parts = []
        if s["headline_family"] and s["headline_family"] == s["body_family"]:
            parts.append(f"{s['headline_family']} for headlines and body")
        else:
            if s["headline_family"]:
                parts.append(f"headlines in {s['headline_family']}")
            if s["body_family"]:
                parts.append(f"body in {s['body_family']}")
        rules.append(f"Fonts: {', '.join(parts)} ({who}).")
    elif s["families"]:
        rules.append(f"Fonts: {', '.join(s['families'][:2])} ({who}).")
    if s["custom_fonts"]:
        rules.append(f"Custom web fonts on the site: {', '.join(s['custom_fonts'])}. Decide the email fallback for live text before the first build ({who}).")
    if s["semantic"].get("primary"):
        rules.append(f"Primary colour {s['semantic']['primary']} ({who}).")
    if s["buttons"]:
        b = s["buttons"][0]
        bits = [f"fill {b['bg']}" if b["bg"] else None, f"text {b['text']}" if b["text"] else None,
                f"radius {b['radius']}" if b.get("radius") else None]
        rules.append(f"CTA button: {', '.join(x for x in bits if x)} ({who}).")
    return rules


def style_md(s):
    L = [f"## Style guide (extracted)",
         f"Source: {s['url']} · extracted {s['extracted_at'] or '?'} with dembrandt {s['dembrandt'] or '?'}. "
         "These are the website's values. Email clients render less than a browser: check before you treat any of them as a rule.", ""]
    L.append("### Colours")
    if s["semantic"]:
        L.append("| Role | Hex |\n|---|---|")
        L += [f"| {k} | `{v}` |" for k, v in s["semantic"].items()]
        L.append("")
    if s["palette"]:
        L.append("Palette (most used first):\n\n| Hex | Role | Uses | Confidence |\n|---|---|---:|---|")
        L += [f"| `{p['hex']}` | {p['role'] or '-'} | {p['count']} | {p['confidence'] or '-'} |" for p in s["palette"]]
        L.append("")
    if s["css_vars"]:
        L.append("CSS variables: " + " · ".join(f"`{v['name']}` {v['hex']}" for v in s["css_vars"]))
        L.append("")
    if not (s["semantic"] or s["palette"]):
        L += ["No colours in the extraction.", ""]

    L.append("### Type")
    if s["families"]:
        L.append("Families (most used first): " + ", ".join(s["families"]))
        if s["google_fonts"]:
            L.append(f"Google Fonts: {', '.join(s['google_fonts'])}")
        if s["custom_fonts"]:
            L.append(f"Custom fonts: {', '.join(s['custom_fonts'])}")
        L.append("")
    if s["type_styles"]:
        L.append("| Context | Family | Size | Weight | Line height | Tracking |\n|---|---|---|---|---|---|")
        L += [f"| {t['context'] or '-'} | {t['family']} | {t['size']} | {t['weight'] or '-'} | {t['line_height'] or '-'} | {t['tracking'] or '-'} |" for t in s["type_styles"]]
        L.append("")
    else:
        L += ["No type styles in the extraction.", ""]

    L.append("### Components")
    if s["buttons"]:
        L.append("Buttons:\n\n| Fill | Text | Radius | Padding | Size / weight | Hover fill |\n|---|---|---|---|---|---|")
        L += [f"| {b['bg'] or '-'} | {b['text'] or '-'} | {b['radius'] or '-'} | {b['padding'] or '-'} | {b['font_size'] or '-'} / {b['font_weight'] or '-'} | {b['hover_bg'] or '-'} |" for b in s["buttons"]]
        L.append("")
    if s["links"]:
        L.append("Links: " + " · ".join(f"{l['color'] or '?'} {l['decoration'] or ''}, hover {l['hover_color'] or '-'} {l['hover_decoration'] or ''}".strip() for l in s["links"]))
    if s["badges"]:
        L.append("Badges: " + " · ".join(f"{b['bg'] or '?'} on {b['text'] or '?'}, radius {b['radius'] or '-'}" for b in s["badges"]))
    if s["radii"]:
        L.append("Corner radii (most used first): " + ", ".join(s["radii"]))
    if s["spacing"]:
        L.append("Spacing values: " + ", ".join(s["spacing"]))
    if not (s["buttons"] or s["links"] or s["badges"]):
        L.append("No components in the extraction.")
    L.append("")

    L.append("### Motion")
    if s["durations"] or s["easings"] or s["animations"]:
        if s["durations"]:
            L.append("Durations: " + ", ".join(s["durations"]))
        if s["easings"]:
            L.append("Easings: " + ", ".join(f"`{e}`" for e in s["easings"]))
        if s["animations"]:
            L.append("Animations: " + ", ".join(s["animations"]))
        if s["interactions"]:
            L.append("Hover patterns: " + ", ".join(s["interactions"]))
        L.append("Most inboxes don't play CSS motion. Use this for GIF timing and for the brand's feel, not as a rule.")
    else:
        L.append("No motion in the extraction.")
    L.append("")
    if s["breakpoints"]:
        L += ["Breakpoints: " + ", ".join(s["breakpoints"]), ""]
    if s["logo"]:
        L += [f"Logo: {s['logo']}", ""]
    return "\n".join(L)


def rules_file(brand, s, today):
    tpl = TEMPLATE.read_text()
    tpl = tpl.replace("<Brand>", brand).replace("<url>", s["url"] or "<url>")
    props = proposed_rules(s, today)
    block = ["## Proposed (from the site; a human moves each one into Hard or Soft, or deletes it)"]
    block += [f"- {r}" for r in props] if props else ["- Nothing to propose: the extraction had no fonts, primary colour or buttons."]
    return tpl.rstrip() + "\n" + "\n".join(block) + "\n\n" + style_md(s)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("json")
    ap.add_argument("--brand")
    ap.add_argument("--out")
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--style-only", action="store_true")
    ap.add_argument("--summary", action="store_true")
    ap.add_argument("--today", default=date.today().isoformat())
    a = ap.parse_args(argv)
    try:
        d = json.loads(Path(a.json).read_text())
    except (OSError, ValueError) as e:
        print(f"Can't read {a.json}: {e}", file=sys.stderr)
        return 2
    if not isinstance(d, dict) or not (d.get("url") or d.get("colors") or d.get("typography")):
        print("This doesn't look like a dembrandt extraction (no url, colors or typography).", file=sys.stderr)
        return 2
    s = summarize(d)
    if a.summary:
        print(json.dumps(s, indent=2, ensure_ascii=False))
        return 0
    brand = a.brand or s["site"] or "Brand"
    text = style_md(s) if a.style_only else rules_file(brand, s, a.today)
    if not a.out:
        print(text)
        return 0
    out = Path(a.out)
    if out.exists() and not a.force:
        print(f"{out} already exists. It may hold approved rules: write the style guide elsewhere with "
              f"--style-only --out {out.with_name('STYLE.md')}, or pass --force to replace it.", file=sys.stderr)
        return 3
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(text)
    print(f"Wrote {out} ({len(s['palette'])} colours, {len(s['families'])} families, {len(s['buttons'])} buttons). "
          f"Slug: {slug(brand)}. Proposed rules wait for a human yes.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
