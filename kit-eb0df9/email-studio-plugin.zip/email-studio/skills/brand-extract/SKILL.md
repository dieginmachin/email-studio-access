---
name: brand-extract
description: "Stage 2 · Brand. Point it at a brand's website and get the brand's colours, type, components and motion as a BRAND.md, with The Rules File skeleton on top and proposed rules waiting for a human yes. Runs the public dembrandt CLI (npx dembrandt <url>). Use for 'extract this brand', 'get the brand's colours and fonts', 'start a new brand', 'brand style guide from the site', or when someone pastes a brand's URL."
---

# Brand extract (Stage 2)

Turns a brand's website into the first draft of its Rules File. The website's values are evidence, not rules: everything the site suggests lands under **Proposed** until a human moves it into Hard or Soft.

## Workflow

1. **Get the URL and the brand name.** Ask whether the brand has a dark mode or a mobile-only look worth a second pass, and for 1 to 3 extra pages that show products (a product page shows buttons and prices best).
2. **Run dembrandt** (Claude Code, or any machine with Node 18+). In the brand's folder:
   ```bash
   mkdir -p brands/<slug>/extract && cd brands/<slug>/extract
   npx --yes dembrandt <url> [/products/<handle> ...] --save-output --design-md --screenshot screenshot.png
   ```
   It writes `output/<domain>/<timestamp>.json` and `output/<domain>/DESIGN.md`.
   Useful flags (check `npx dembrandt --help` for the full list):
   - `--mobile` mobile viewport · `--dark-mode` dark colours · `--slow` for slow sites
   - `--crawl 5` follow up to 5 links on the same site · `--sitemap` use sitemap.xml instead
   - `--wcag` contrast ratios between palette colours · `--html report.html` a visual report · `--dtcg` W3C design tokens
   If it says no browser is installed, run `npx playwright install chromium` once and try again. If the site blocks it, try `--slow`, then ask for screenshots instead.
3. **Write BRAND.md.**
   ```bash
   python3 scripts/brand_md.py brands/<slug>/extract/output/<domain>/<file>.json --brand "<Brand>" --out brands/<slug>/BRAND.md
   ```
   If BRAND.md already exists, the script refuses to overwrite it (it may hold approved rules). Write the style guide next to it instead: `--style-only --out brands/<slug>/STYLE.md`. `--summary` prints the parsed values as JSON and writes nothing.
4. **Look at the screenshot** and the summary together. Say what the extraction can't know: email fonts (custom web fonts often don't render in inboxes), photo style, and anything behind a login.
5. **Stop at the human.** Show the Proposed rules one by one and ask: "Move this into Hard, Soft, or delete it?" Then fill the Files, PM, Hub and Reviewer lines with them. Next step: `rules-sweep` for the client's own feedback, then `library-digest`.

## Claude app
The app can't run `npx`. Ask the person to run `npx dembrandt <url> --save-output` on their computer and attach the JSON from `output/<domain>/`, then do step 3 with the attached file and give them BRAND.md back.

## Files
- `scripts/brand_md.py`: dembrandt JSON → BRAND.md (Python 3, no dependencies).
- `templates/BRAND.md`: The Rules File skeleton (Hard blocks export, Soft warns, each rule with who and when).
- `examples/fernhill.dembrandt.json`: a made-up extraction for the fictional sample brand. `examples/example-com.dembrandt.json`: a real dembrandt 0.39.2 run on example.com.

## Rules
- Every value comes from the extraction. Never fill a gap with a guess; say it's missing.
- Proposed is not Hard. Nothing becomes a rule without a human yes, with who and when.
- Don't extract sites the person has no reason to study; it's for brands they design for.
