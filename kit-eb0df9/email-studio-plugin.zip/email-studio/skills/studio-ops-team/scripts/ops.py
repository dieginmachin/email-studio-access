#!/usr/bin/env python3
"""Team Nº 02 · Studio Ops. No dependencies.

  python3 ops.py triage BRIEFS.csv [--today YYYY-MM-DD]   missing fields, priority, routing, prep level
  python3 ops.py report STATUS_LOG.csv                    where time goes, every number with its source

BRIEFS.csv columns: brand, email_type, topic, objective, cta_url, design_due, send_date, copy_status, approved_templates
STATUS_LOG.csv columns: task, status, entered_at   (ISO date or datetime; one row per status change)
"""
import csv, json, statistics, sys
from datetime import date, datetime
from pathlib import Path

REQUIRED = ["brand", "email_type", "topic", "objective", "cta_url", "design_due", "send_date", "copy_status"]
SENIOR_UNTIL = 10  # new brands start with a senior designer until 10 templates are approved
COPY_READY = {"ready", "final", "approved", "done"}


def d(s):
    s = (s or "").strip()
    if not s:
        return None
    for fmt in ("%Y-%m-%d", "%Y-%m-%dT%H:%M", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M", "%m/%d/%Y"):
        try:
            return datetime.strptime(s[:19], fmt)
        except ValueError:
            pass
    return None


def triage(rows, today=None):
    out = []
    for i, r in enumerate(rows, 1):
        r = {k.strip(): (v or "").strip() for k, v in r.items() if k}
        missing = [f for f in REQUIRED if not r.get(f)]
        if r.get("cta_url") and not r["cta_url"].startswith("https://"):
            missing.append("cta_url (not a full https link)")
        due, send = d(r.get("design_due")), d(r.get("send_date"))
        flags = []
        if due and send and due > send:
            flags.append("design due after send date")
        if today and due and due.date() < today:
            flags.append("design due date already passed")
        try:
            approved = int(r.get("approved_templates") or 0)
        except ValueError:
            approved = 0
        copy_ready = r.get("copy_status", "").lower() in COPY_READY
        out.append({
            "row": i,
            "brief": " · ".join(x for x in (r.get("brand"), r.get("email_type"), r.get("topic")) if x) or f"row {i}",
            "missing": missing,
            "flags": flags,
            "route": "senior designer" if approved < SENIOR_UNTIL else "brand designer",
            "route_why": f"{approved} approved templates (senior until {SENIOR_UNTIL})",
            "prep": "P1 Match, then finish" if copy_ready else "P2 Skeleton (copy not ready: placeholder copy with word limits)",
            "_due": due or datetime.max, "_send": send or datetime.max,
        })
    out.sort(key=lambda x: (bool(x["missing"]), x["_due"], x["_send"]))
    for k, x in enumerate(out, 1):
        x["priority"] = k
        x["ready"] = not x["missing"]
        del x["_due"], x["_send"]
    return out


def report(rows, source="status log"):
    """Hours spent in each status, from consecutive status changes per task. Open last statuses are not counted."""
    by = {}
    for r in rows:
        t = d(r.get("entered_at"))
        if not r.get("task") or not r.get("status") or not t:
            continue
        by.setdefault(r["task"].strip(), []).append((t, r["status"].strip().lower()))
    spent = {}
    for task, ev in by.items():
        ev.sort()
        for (t0, s0), (t1, _) in zip(ev, ev[1:]):
            spent.setdefault(s0, []).append((t1 - t0).total_seconds() / 3600)
    total = sum(sum(v) for v in spent.values()) or 1
    lines = []
    for s, hrs in sorted(spent.items(), key=lambda kv: -sum(kv[1])):
        lines.append({
            "status": s,
            "tasks": len(hrs),
            "median_hours": round(statistics.median(hrs), 1),
            "share_of_time": round(100 * sum(hrs) / total),
            "source": f"{source}: columns task, status, entered_at ({len(hrs)} transitions)",
        })
    biggest = lines[0]["status"] if lines else None
    return {
        "tasks": len(by),
        "where_time_goes": lines,
        "biggest_wait": biggest,
        "sample_warning": "Fewer than 30 tasks: describe it, don't claim it." if len(by) < 30 else None,
        "rules": ["Results, not goals: only what the log shows.", "Correlation, not cause.", "No borrowed benchmarks."],
    }


def main(a):
    if len(a) < 2:
        print(__doc__)
        return 2
    with open(a[1], newline="", encoding="utf-8-sig") as f:
        rows = list(csv.DictReader(f))
    if a[0] == "triage":
        today = date.fromisoformat(a[a.index("--today") + 1]) if "--today" in a else None
        print(json.dumps({"briefs": triage(rows, today)}, indent=2))
        return 0
    if a[0] == "report":
        print(json.dumps(report(rows, Path(a[1]).name), indent=2))
        return 0
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
