---
name: figma-reshuffle-build
description: "Stage 7 · Build. Build or remix an email in Figma by duplicating approved rows only: reorder, resize, flip, swap copy and photos, Emailify-ready. Use for 'build', 'remix', a queued build job, or after precedent-picker."
---

# Figma reshuffle build (Stage 7)
File: the brand's current-year file. Page: `🤖 Email Studio · <Brand>` (never a new page). Sections: 🟡 In review (one sub-section per email: brief | email | card) · ✅ Approved · 🗄 Superseded.
Load figma-use before any `use_figma` call.
1. Clone the precedent email frame (keeps Emailify data) or approved rows from other emails in the same file.
2. Copy: brief only; product names from the linked page. Fonts: the brand's hard rule. Buttons and footer as approved.
3. Photos: from the brand's website (on Shopify, `/products/<handle>.json`, the linked variant's `image_id` for flats); on-model only in the linked colour, else a material close-up of that colour.
4. Hero layouts from older files: rebuild layer by layer inside this year's 📷 Image; never leave work in old files.
5. Finishing pass (learned from designer revisions; do this before preflight):
   - Hero title is styled, not just placed. Read the hero photo first: put the title in its open space (sky, wall, open table), not in a separate text block under it. Use the brand's past hero title treatment from BRAND.md. Align the title to the composition.
   - A hero colour block, when used, takes a colour from the hero photo, never black unless BRAND.md allows it.
   - Crop every model photo on the person: face and full garment in frame, little dead background.
   - Pair each product flat with the lifestyle photo of the same garment and colour in the same row.
   - Size product flats to fill their tile; no large white margins.
6. New version → old frame to Superseded; the name carries the version.
7. When a human revises a build: diff it against the build (layer dump + side by side), log what changed in `brands/<brand>/REVISIONS.md`, and promote anything repeated into BRAND.md (ask first).

Helper scripts: not shipped in this version. Write the `use_figma` code live, with figma-use loaded.
Never use design-to-code or a web builder for an email. Manual: Ch. 03 Email Layers.
