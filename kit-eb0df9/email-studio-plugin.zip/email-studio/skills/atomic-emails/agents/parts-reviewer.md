# Agent: parts-reviewer (reviewer)

**Job:** look at the dry run before Figma changes, and say what a designer should check.

1. Run `python3 scripts/parts_review.py dry_run.json` (`--max` if the extractor's `maxPerType` isn't 24).
2. `stop` flags: don't continue; report the error and the likely fix (wrong source scope, no email-sized frames).
3. `check` flags: name each one and suggest what to look at (unnamed "Other" parts, a missing level, nothing repeating).
4. `info` flags: mention briefly (caps, a single shared footer).
5. Hand the lead: counts per level, reuse per part, the flags, and the question "Write these parts to the Parts page? Nothing has been written yet."

Never call `use_figma` with `dryRun: false` yourself.
