---
name: atomic-emails
description: "Stage 5 · Atomic. The Atomic Emails method as a team in Figma: the extractor dry-runs and then builds a Parts page of organisms, molecules and atoms from approved emails, the parts reviewer flags unnamed parts, caps and missing levels before anything is written, and a human says yes. Never touches the source emails. Use for 'atomize', 'extract parts', 'break this email into sections', 'build a parts library', 'Atomic Emails extractor', or a Figma file of emails that should become reusable sections, cards and buttons. Needs the Figma connector (Figma MCP)."
---

# Atomic Emails (Stage 5)

From Diego Garza's Atomic Emails workshop (Jan 2026): one approved section can become many designs, once it is a part. **Elements → Containers → Sections** (atoms → molecules → organisms).

```
lead (this file)  →  extractor (agents/extractor.md)  →  parts-reviewer (agents/parts-reviewer.md)  →  HUMAN: write it?
```

## House rules
1. Never modify, move or delete the source emails.
2. Dry run first. The parts reviewer reads the dry run before anything is written.
3. A human says yes before the Parts page changes.
4. If `use_figma` fails partway, read the Parts page before running again, so you don't make duplicates.

## What becomes what
| In the email | Level | Example names |
|---|---|---|
| A full-width row (Emailify 🚣 Row, or any full-width child of the email). 🎁 wrappers are opened; whole headers and footers stay whole | **Organism** (section) | Hero, Product grid, Reviews, Footer, Text & CTA |
| A column inside a row with two or more columns (Emailify 🏛️ Column) | **Molecule** (container) | Card (image, text, button), Image + text |
| Buttons (🔗), tags and badges, logos, social icon rows | **Atom** (element) | Button / Shop now, Badge, Logo |

Clean Email Layers make this cleaner: run `email-layers` first on a messy file.

## Workflow
1. **Scope.** Get the Figma file link and which emails to atomize: a Figma Section (one brand), one or more pages (`pages:`), or the selection. Big files: one brand section at a time. Say exactly what will change: a page named **Parts**, with components. On a Figma Starter plan (3 pages max), if there is no room, ask which page to use (`partsPage`) or suggest a duplicate of the file.
2. **Start a Figma session.** `create_session` with the file key, then load the `figma-use` skill before any `use_figma` call.
3. **Dry run (extractor).** Send `scripts/extract.figma.js` through `use_figma` with `dryRun: true` and the chosen `source` (edit only the `CONFIG` block at the top). Save the returned JSON as `dry_run.json`.
4. **Review (parts reviewer).** `python3 scripts/parts_review.py dry_run.json` (`--max` if `maxPerType` isn't 24).
5. **Stop at the human.** Show the counts per level, the reuse per part and every flag. Ask: "Write these parts to the Parts page? Nothing has been written yet."
6. **On yes, extract.** Same script with `dryRun: false`, one brand section at a time. For a big run, one level per call (`levels: ['Organisms']`, then `['Molecules', 'Atoms']`) so a timeout never leaves a half-built page.
7. **Check and hand off.** One `get_screenshot` of the Parts page; offer to delete stray parts (decorations, tiny images) only if the designer agrees. Tell them the counts per level, the most-reused parts, and that the Template Auto-Sorter (https://dieginmachin.github.io/template-auto-sorter/) shows the Parts page in Parts mode after Files → Re-sort from Figma.

## Output contract (what the Auto-Sorter reads)
Page **Parts** → sections **Organisms**, **Molecules**, **Atoms**; in each, one dashed group per type (a label like `HERO   12` and a grid of components). Components are named `Type / Brand NN` (organisms, molecules) or `Button / <label>` (atoms). Identical parts collapse into one; each component's description names the email it came from and how many emails use it.

## Files
- `scripts/extract.figma.js`: the Atomic Emails extractor (Figma Plugin API code for `use_figma`).
- `scripts/parts_review.py`: reads the dry run and returns counts, reuse and flags (stop / check / info).
- `agents/extractor.md`, `agents/parts-reviewer.md`, `examples/dry_run.json`.

Next stage: `copy-template-match` and `precedent-picker` remix from these parts.
