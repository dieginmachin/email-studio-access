#!/usr/bin/env python3
"""Team Nº 04 · Atomic: the parts reviewer. No dependencies.

  python3 parts_review.py DRY_RUN.json [--max 24]

Reads the JSON that scripts/extract.figma.js returns with dryRun: true and flags what a designer
should look at before anything is written to Figma. It never writes.
"""
import json, sys
from pathlib import Path

LEVELS = ("Organisms", "Molecules", "Atoms")


def review(s, max_per_type=24):
    if "error" in s:
        return {"go": False, "flags": [{"level": "stop", "what": s["error"]}], "counts": {}}
    flags, counts = [], {lv: 0 for lv in LEVELS}
    for k, n in s.get("byGroup", {}).items():
        lv, typ = k.split("|", 1)
        counts[lv] = counts.get(lv, 0) + n
        if typ == "Other":
            flags.append({"level": "check", "what": f"{k}: {n} parts the script couldn't name. Likely decorations or odd rows. Look before writing."})
        if n >= max_per_type:
            flags.append({"level": "info", "what": f"{k}: capped at {max_per_type}. Only the most-used parts are kept."})
        if n == 1 and typ != "Other" and s.get("emails", 0) >= 5:
            flags.append({"level": "info", "what": f"{k}: one shared part across {s['emails']} emails. Expected for headers and footers."})
    for lv in LEVELS:
        if counts.get(lv, 0) == 0:
            flags.append({"level": "check", "what": f"No {lv.lower()} found. Check the source scope or the levels setting."})
    found, unique = s.get("found", 0), s.get("unique", 0)
    reuse = round(found / unique, 2) if unique else None
    if reuse is not None and reuse < 1.1 and s.get("emails", 0) >= 5:
        flags.append({"level": "check", "what": f"Almost nothing repeats ({found} parts, {unique} unique). The emails may not share a layer structure yet."})
    go = not any(f["level"] == "stop" for f in flags)
    return {"go": go, "emails": s.get("emails"), "found": found, "unique": unique, "kept": s.get("kept"),
            "reuse_per_part": reuse, "counts": counts, "flags": flags,
            "ask": "Write these parts to the Parts page? Nothing has been written yet."}


if __name__ == "__main__":
    a = sys.argv[1:]
    if not a:
        print(__doc__)
        sys.exit(2)
    mx = int(a[a.index("--max") + 1]) if "--max" in a else 24
    print(json.dumps(review(json.loads(Path(a[0]).read_text()), mx), indent=2))
