// Atomic Emails extractor: run with the Figma MCP `use_figma` tool.
// Edit CONFIG, then send this whole file as the `code` argument. It never edits the source emails:
// it clones parts onto a "Parts" page, turns them into components and lays them out like the
// Template Auto-Sorter canvas (one dashed group per type, with a label and a count).
const CONFIG = {
  source: 'selection',   // 'selection' | 'section:<Section name>' | 'page:<Page name>' | 'pages:<Page A>|<Page B>' | ['12:34', '12:35']
  brand: null,           // one client per file? set its name here; otherwise the enclosing section (or file) name is the brand
  partsPage: 'Parts',    // created if missing (Starter plans allow 3 pages per file)
  levels: ['Organisms', 'Molecules', 'Atoms'],
  maxPerType: 24,        // keeps the page light; the most-used parts win
  dryRun: false          // true = count only, write nothing
};

/* ---------- read ---------- */
const clean = s => String(s || '').replace(/[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE0F}\u{200D}]/gu, ' ').replace(/\s+/g, ' ').trim();
const bare = s => clean(s).replace(/\((row|wrapper|wrapped)[^)]*\)/ig, '').replace(/\((for )?content (columns|elements)\)/ig, '').replace(/\s+/g, ' ').trim() || clean(s);
const kids = n => ('children' in n ? n.children : []).filter(c => c.visible !== false);
const GIFT = /\u{1F381}/u, COL = /\u{1F3DB}/u, LINK = /\u{1F517}/u;
const ORG = [
  ['Announcement bar', /announcement|alert bar|pre-?header|ticker|top bar/i], ['Header & logo', /header|\blogo\b|\bnav\b|navigation|menu/i],
  ['Footer', /footer|unsubscribe|legal/i], ['Hero', /hero|banner|above the fold/i], ['Product grid', /product|klaviyo|feed|\bshop\b|catalog|collection/i],
  ['Reviews', /review|testimon|rating|social proof|trust ?pilot|\bugc\b/i], ['Discount code', /discount|coupon|promo code|c[oó]digo|voucher/i],
  ['Countdown', /countdown|timer/i], ['Articles & listicle', /article|blog|listicle/i], ['Bento', /bento/i], ['Video', /video|\bgif\b/i],
  ['Features & USPs', /\busps?\b|feature|icon|benefit|table|shipping|calendar|guarantee/i], ['Image gallery', /gallery|full image|\bimages?\b|photo|two images|captioned/i],
  ['Text & CTA', /title|paragraph|text|heading|headline|button|\bcta\b|copy|split/i], ['Custom code', /custom code|code block/i], ['Divider & spacer', /spacer|divider|separator/i]
];
const first = (list, s) => (list.find(x => x[1].test(s)) || [])[0] || null;
function texts(n, out = [], d = 0) { if (n.type === 'TEXT') out.push(n.characters); if (d < 6) kids(n).forEach(c => texts(c, out, d + 1)); return out; }
function hash(s) { let h = 5381; for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return (h >>> 0).toString(36); }
const fp = (lvl, n) => [lvl, bare(n.name).toLowerCase().replace(/\d+/g, '#'), Math.round(n.width / 2) + 'x' + Math.round(n.height / 2), kids(n).map(c => bare(c.name).toLowerCase().replace(/\d+/g, '#')).join(','), hash(texts(n).join('¦').slice(0, 400))].join('|');
function recipe(col) {
  const has = {}; const walk = (n, d) => { const nm = clean(n.name).toLowerCase(); if (n.type === 'TEXT') has.text = 1; else if (LINK.test(n.name) || /button|\bbtn\b|\bcta\b/.test(nm)) has.button = 1; else if (/image|img|photo|\u{1F4F7}/u.test(n.name.toLowerCase()) || n.type === 'RECTANGLE') has.image = 1; else if (/table/.test(nm)) has.table = 1; if (d < 3) kids(n).forEach(c => walk(c, d + 1)); };
  kids(col).forEach(c => walk(c, 0));
  if (has.table) return 'Table';
  const p = []; if (has.image) p.push('Image'); if (has.text) p.push('text'); if (has.button) p.push('button');
  const s = p.join(' + ') || 'Other'; return s.charAt(0).toUpperCase() + s.slice(1);
}
function atomize(email, brand) {
  const out = [], W = email.width || 600;
  const rec = (n, level, type, title) => out.push({ node: n, level, type, title: title || bare(n.name), brand, src: clean(email.name), email: email.id, fp: (level === 'Atoms' ? brand + '|' : '') + fp(level, n) }); // atoms carry brand styling
  const wrapperish = n => (GIFT.test(n.name) || /wrapper|layouts?\s*\//i.test(n.name)) && !/footer|header/i.test(bare(n.name)) && kids(n).some(k => k.type !== 'TEXT' && k.width >= W * 0.8);
  function atoms(n, d) {
    for (const c of kids(n)) {
      const nm = clean(c.name).toLowerCase(); let t = null;
      if (LINK.test(c.name) || /^(button|btn|cta)\b/.test(nm)) t = 'Button';
      else if (/\b(tag|badge|label|pill|sticker)\b/.test(nm) && c.type !== 'TEXT') t = 'Badge';
      else if (/\blogo\b/.test(nm) && c.type !== 'TEXT') t = 'Logo';
      else if (/social/.test(nm)) t = 'Social icons';
      if (t) rec(c, 'Atoms', t, clean(texts(c)[0] || '').slice(0, 32) || t);
      else if (d < 4 && c.type !== 'INSTANCE' && c.type !== 'TEXT') atoms(c, d + 1);
    }
  }
  function organism(n, d = 0) {
    if (d < 3 && wrapperish(n)) { kids(n).forEach(k => { if (k.type !== 'TEXT' && k.width >= W * 0.8) organism(k, d + 1); }); return; }
    const nm = bare(n.name); let type = first(ORG, nm);
    let cols = kids(n).filter(c => COL.test(c.name) || /column/i.test(c.name));
    if (!cols.length) cols = kids(n).filter(c => c.type !== 'TEXT' && c.width < W * 0.6 && c.height > 40);
    if (!type) { const rc = recipe(n); type = cols.length >= 2 ? (recipe(cols[0]).startsWith('Image') && recipe(cols[0]).includes('button') ? 'Product grid' : 'Image gallery') : rc === 'Image' ? 'Image gallery' : /text|button/i.test(rc) ? 'Text & CTA' : 'Other'; }
    rec(n, 'Organisms', type);
    if (cols.length >= 2 && !/Footer|Header|Announcement/.test(type)) cols.forEach(c => { const r = recipe(c); rec(c, 'Molecules', r === 'Image + text + button' ? 'Card' : r, r + ' · ' + nm); });
    atoms(n, 0);
  }
  for (const c of kids(email)) {
    if (c.type === 'TEXT' || c.type === 'VECTOR') continue;
    const whole = /footer|header/i.test(bare(c.name));
    if ((!whole && wrapperish(c)) || c.width >= W * 0.8) organism(c);
  }
  return out;
}
const isEmail = n => ['FRAME', 'COMPONENT', 'INSTANCE'].includes(n.type) && n.width >= 320 && n.width <= 900 && n.height >= n.width * 0.75 && !/^\s*(\u{1F6A3}|\u{1F381})/u.test(n.name);

/* ---------- collect the emails ---------- */
let emails = [], srcPage = figma.currentPage;
if (CONFIG.source === 'selection') emails = figma.currentPage.selection.slice();
else if (Array.isArray(CONFIG.source)) emails = (await Promise.all(CONFIG.source.map(id => figma.getNodeByIdAsync(id)))).filter(Boolean);
else if (CONFIG.source.startsWith('page:')) { srcPage = figma.root.children.find(p => p.name === CONFIG.source.slice(5)); await srcPage.loadAsync(); emails = srcPage.children.slice(); }
else if (CONFIG.source.startsWith('pages:')) {
  const names = CONFIG.source.slice(6).split('|').map(s => s.trim());
  for (const p of figma.root.children) { if (!names.includes(p.name)) continue; await p.loadAsync(); emails = emails.concat(p.children); }
}
else if (CONFIG.source.startsWith('section:')) {
  const name = CONFIG.source.slice(8);
  for (const p of figma.root.children) { if (p.name === CONFIG.partsPage) continue; await p.loadAsync(); const s = p.findOne(n => n.type === 'SECTION' && n.name === name); if (s) { srcPage = p; emails = s.children.slice(); break; } }
}
const brandOf = n => { if (CONFIG.brand) return CONFIG.brand; let p = n.parent; while (p && p.type !== 'PAGE') { if (p.type === 'SECTION') return clean(p.name); p = p.parent; } return clean(figma.root.name); };
emails = emails.flatMap(n => isEmail(n) ? [n] : ('children' in n ? n.children.filter(isEmail) : []));
if (!emails.length) return { error: 'No emails found for source ' + JSON.stringify(CONFIG.source) + '. Emails are frames 320–900px wide and taller than they are wide.' };

/* ---------- atomize + dedupe ---------- */
let raw = []; for (const e of emails) raw = raw.concat(atomize(e, brandOf(e)));
const by = new Map();
for (const p of raw) { const h = by.get(p.fp); if (!h) by.set(p.fp, Object.assign(p, { uses: 1, srcs: [p.src], ids: new Set([p.email]) })); else if (!h.ids.has(p.email)) { h.ids.add(p.email); h.uses++; if (h.srcs.length < 6) h.srcs.push(p.src); } } // count each email once
const groups = new Map();
for (const p of by.values()) { if (!CONFIG.levels.includes(p.level)) continue; const k = p.level + '|' + p.type; if (!groups.has(k)) groups.set(k, []); groups.get(k).push(p); }
for (const [k, list] of groups) { list.sort((a, b) => b.uses - a.uses); groups.set(k, list.slice(0, CONFIG.maxPerType)); }
const summary = { emails: emails.length, found: raw.length, unique: by.size, kept: [...groups.values()].reduce((a, l) => a + l.length, 0),
  byGroup: Object.fromEntries([...groups].map(([k, l]) => [k, l.length])) };
if (CONFIG.dryRun) return summary;

/* ---------- write: Parts page, one section per level, one dashed group per type ---------- */
let page = figma.root.children.find(p => p.name === CONFIG.partsPage);
if (!page) { page = figma.createPage(); page.name = CONFIG.partsPage; }
await figma.setCurrentPageAsync(page);
await Promise.all([{ family: 'Inter', style: 'Bold' }, { family: 'Inter', style: 'Regular' }].map(f => figma.loadFontAsync(f)));
const rgb = h => ({ r: parseInt(h.slice(1, 3), 16) / 255, g: parseInt(h.slice(3, 5), 16) / 255, b: parseInt(h.slice(5, 7), 16) / 255 });
const COLS = { Organisms: 3, Molecules: 5, Atoms: 6 };
const created = [];
let y = page.children.reduce((m, n) => Math.max(m, n.y + n.height), 0) + (page.children.length ? 200 : 0);
for (const level of CONFIG.levels) {
  const entries = [...groups].filter(([k]) => k.startsWith(level + '|'));
  if (!entries.length) continue;
  let sec = page.children.find(n => n.type === 'SECTION' && n.name === level);
  const fresh = !sec;
  if (fresh) { sec = figma.createSection(); sec.name = level; sec.x = 0; sec.y = y; sec.fills = [{ type: 'SOLID', color: rgb('#e9eeeb') }]; }
  let gx = 80, gy = 120 + (fresh ? 0 : sec.children.reduce((m, n) => Math.max(m, n.y + n.height), 0)), rowH = 0, maxW = 0;
  for (const [k, list] of entries) {
    const type = k.split('|')[1];
    // group = dashed frame (label on top, wrapping grid of parts below), like the Auto-Sorter canvas
    const g = figma.createAutoLayout('VERTICAL', { name: type, itemSpacing: 16, paddingTop: 22, paddingBottom: 28, paddingLeft: 28, paddingRight: 28 });
    g.fills = []; g.cornerRadius = 14; g.strokes = [{ type: 'SOLID', color: rgb('#a9b5ae') }]; g.dashPattern = [8, 6]; g.strokeWeight = 1.5;
    sec.appendChild(g);
    const lab = figma.createText(); lab.fontName = { family: 'Inter', style: 'Bold' }; lab.characters = type.toUpperCase() + '   ' + list.length; lab.fontSize = 13; lab.letterSpacing = { unit: 'PERCENT', value: 8 };
    lab.fills = [{ type: 'SOLID', color: rgb('#101a15') }]; lab.name = 'Label'; g.appendChild(lab);
    const colW = Math.max(...list.map(p => p.node.width));
    const grid = figma.createFrame(); grid.name = type + ' parts'; grid.fills = []; grid.layoutMode = 'HORIZONTAL'; grid.layoutWrap = 'WRAP'; grid.itemSpacing = 32; grid.counterAxisSpacing = 40;
    grid.resize(Math.max(colW, Math.min(COLS[level], list.length) * (colW + 32) - 32), 100); grid.primaryAxisSizingMode = 'FIXED'; grid.counterAxisSizingMode = 'AUTO';
    g.appendChild(grid);
    list.forEach((p, i) => {
      let c = p.node.clone(); if (c.type === 'INSTANCE') c = c.detachInstance();
      grid.appendChild(c);
      // Emailify columns "fill container": pin the clone to its size in the email, or it collapses in the grid
      if (c.layoutSizingHorizontal === 'FILL') c.layoutSizingHorizontal = 'FIXED';
      if (c.layoutSizingVertical === 'FILL') c.layoutSizingVertical = 'FIXED';
      if (Math.abs(c.width - p.node.width) > 1 || Math.abs(c.height - p.node.height) > 1) c.resize(p.node.width, p.node.height);
      const comp = c.type === 'COMPONENT' ? c : figma.createComponentFromNode(c);
      const label = level === 'Atoms' ? p.title : p.brand + ' ' + String(i + 1).padStart(2, '0');
      comp.name = (level === 'Molecules' ? p.type : type) + ' / ' + label;
      comp.description = 'From "' + p.src + '"' + (p.uses > 1 ? ' · used in ' + p.uses + ' emails' : '') + '. Extracted by atomic-extractor.';
      created.push(comp.id);
    });
    if (gx > 80 && gx + g.width > 6000) { gx = 80; gy += rowH + 80; rowH = 0; }
    g.x = gx; g.y = gy; gx += g.width + 80; rowH = Math.max(rowH, g.height); maxW = Math.max(maxW, gx);
  }
  sec.resizeWithoutConstraints(Math.max(sec.width, maxW + 20), Math.max(sec.height, gy + rowH + 100));
  y = sec.y + sec.height + 200;
}
return Object.assign(summary, { page: page.id, createdComponents: created.length, createdNodeIds: created.slice(0, 50) });
