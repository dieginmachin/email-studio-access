#!/usr/bin/env python3
"""Team Nº 03 · Model Review. No dependencies.

  python3 evals.py evalset DRAFTS.csv RULEBOOK.json        a scoring sheet: one row per draft × rule (CSV to stdout)
  python3 evals.py agreement AI.csv HUMAN.csv [--min 30]   how often the AI reviewer agrees with the human

DRAFTS.csv:  design            (optional: brand, made_by)
AI.csv:      design, issue, human_decision   (accepted | rejected; one row per AI comment)
HUMAN.csv:   design, issue                   (what the senior reviewer caught on the same designs)
issue is a short key, e.g. a rule id (H01) or a word ("cta-size"). Same key = same issue.
"""
import csv, json, sys
from pathlib import Path


def rows(p):
    with open(p, newline="", encoding="utf-8-sig") as f:
        return [{k.strip(): (v or "").strip() for k, v in r.items() if k} for r in csv.DictReader(f)]


def evalset(drafts, book):
    out = []
    for d in drafts:
        for r in book.get("rules", []):
            out.append({"design": d["design"], "made_by": d.get("made_by", ""), "rule": r["id"],
                        "statement": r["statement"], "kind": r["kind"], "ai_verdict": "", "human_verdict": "", "note": ""})
    return out


def agreement(ai, human, min_designs=30):
    key = lambda r: (r["design"].lower(), r["issue"].lower())
    ai_set = {key(r): r.get("human_decision", "").lower() for r in ai if r.get("design") and r.get("issue")}
    hu_set = {key(r) for r in human if r.get("design") and r.get("issue")}
    decided = {k: v for k, v in ai_set.items() if v in ("accepted", "rejected")}
    accepted = sum(1 for v in decided.values() if v == "accepted")
    caught = len(hu_set & set(ai_set))
    designs = {k[0] for k in ai_set} | {k[0] for k in hu_set}
    issues = sorted({k[1] for k in ai_set} | {k[1] for k in hu_set})
    per = []
    for i in issues:
        a = {k for k in ai_set if k[1] == i}
        h = {k for k in hu_set if k[1] == i}
        acc = sum(1 for k in a if ai_set[k] == "accepted")
        per.append({"issue": i, "ai_comments": len(a), "accepted": acc, "human_catches": len(h), "ai_also_caught": len(a & h)})
    pct = lambda n, d: None if not d else round(100 * n / d)
    return {
        "designs": len(designs),
        "ai_comments": len(ai_set),
        "undecided": len(ai_set) - len(decided),
        "accepted_pct": pct(accepted, len(decided)),
        "human_catches": len(hu_set),
        "ai_caught_pct": pct(caught, len(hu_set)),
        "missed_by_ai": sorted(f"{d} · {i}" for d, i in hu_set - set(ai_set)),
        "per_issue": per,
        "enough_to_claim": len(designs) >= min_designs,
        "note": (f"Only {len(designs)} designs. Report it as a pilot, not a result." if len(designs) < min_designs
                 else "Sample is large enough to report, with its date range and who reviewed."),
        "definitions": {"accepted_pct": "AI comments the human accepted / AI comments the human decided on",
                        "ai_caught_pct": "human catches the AI also raised / all human catches"},
    }


def main(a):
    if len(a) < 3:
        print(__doc__)
        return 2
    if a[0] == "evalset":
        sheet = evalset(rows(a[1]), json.loads(Path(a[2]).read_text()))
        w = csv.DictWriter(sys.stdout, fieldnames=list(sheet[0].keys()) if sheet else ["design"])
        w.writeheader()
        w.writerows(sheet)
        return 0
    if a[0] == "agreement":
        mn = int(a[a.index("--min") + 1]) if "--min" in a else 30
        print(json.dumps(agreement(rows(a[1]), rows(a[2]), mn), indent=2))
        return 0
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
