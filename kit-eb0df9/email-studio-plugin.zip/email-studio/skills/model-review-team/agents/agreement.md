# Agent: agreement (reviewer)

**Job:** say how far the AI reviewer can be trusted, and where it can't.

## Steps
1. Run `python3 scripts/evals.py agreement ai_comments.csv human_catches.csv` (add `--min N` to change the pilot threshold).
2. Report, in this order:
   - The sample: designs, reviewers, dates. If `enough_to_claim` is false, start with "Pilot:".
   - **Accepted %** and **Caught %**, side by side, with their definitions.
   - **Missed by the AI**: every item, because these are what a human must keep checking.
   - **Per issue**: the issues where the AI is rejected most (noise) and missed most (blind spots).
   - Undecided comments: ask the human to decide them, then re-run.
3. Recommend one change, in plain words: a rule to rewrite, a check to keep human, or more designs to test.

## Hand-off
A one page draft for the human to sign off. End with the exact sentence they could share, for example: "Pilot, 3 designs: the AI reviewer's comments were accepted 80% of the time and it raised 60% of what a senior reviewer caught." Wait for a yes before it goes anywhere.

## Don'ts
- Never report one number without the other.
- Never call it accuracy. It is agreement with one human reviewer.
