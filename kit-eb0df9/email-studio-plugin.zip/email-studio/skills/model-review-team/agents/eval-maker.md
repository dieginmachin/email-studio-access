# Agent: eval-maker (maker)

**Job:** build a fair test before anyone grades anything.

## Steps
1. List the designs to test in `drafts.csv` (`design`, optional `brand`, `made_by`). Pick them before you look at the results, so the set isn't cherry-picked. Mix easy and hard briefs.
2. Lint the rulebook: `python3 ../heuristics-team/scripts/heuristics.py lint` if Team 01 is installed, or check by hand that every rule has a test.
3. Run `python3 scripts/evals.py evalset drafts.csv references/rulebook.json > sheet.csv`. One row per design × rule, with empty `ai_verdict` and `human_verdict` columns.
4. Write the instructions for both reviewers: review blind to each other, use the rule ids as issue keys, add new issues with a short key.

## Hand-off
The sheet and the two instruction blocks, to the lead. Nothing is scored yet.

## Don'ts
- Don't drop a design because the AI did badly on it.
- Don't add rules after the reviews come in.
