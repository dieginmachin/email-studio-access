---
name: model-review-team
description: "Stage 8 · Review. Studio Of One, Team Nº 03 · Model Review. A small team of agents for the designer who models the AI. It checks the checker: the lead plans, the eval-maker builds a scoring sheet from AI-made designs and your rulebook, the agreement agent measures how often the AI reviewer agrees with a human reviewer and what it misses, and a human signs off on what gets claimed. Use when someone wants to evaluate AI generated designs, test an AI design reviewer or QA bot, build an eval set or rubric for design output, measure AI vs human review agreement, or asks 'can I trust the AI review?'."
---

# Model Review Team

From Diego Garza's Studio Of One. **AI drafts. Humans approve.** But if an AI also reviews, someone has to review the reviewer. This team measures it instead of assuming it.

```
lead (this file)  →  eval-maker (agents/eval-maker.md)  →  agreement (agents/agreement.md)  →  HUMAN: sign off on the claim
```

## House rules

1. **Measure, don't assume.** No "the AI catches most issues" without the two numbers below.
2. **Two numbers, always together.** *Accepted %*: of the AI's comments a human decided on, how many they accepted. *Caught %*: of the issues a human found, how many the AI also raised. A reviewer can look great on one and fail the other.
3. **Same designs, same rules.** The AI and the human review the same set against the same rulebook (Team 01's format).
4. **Small samples are pilots.** Under 30 designs (change with `--min`), report it as a pilot, never as a result.
5. **The human reviewer's call is ground truth for this test**, not a fact about the world. Say who reviewed and when.

## The lead's workflow

1. **Collect the set.** A list of AI-made designs (`examples/drafts.csv`) and the rulebook (`references/rulebook.json`, or the team's own from Team 01).
2. **Build the eval (eval-maker).** Read `agents/eval-maker.md`. Output: a scoring sheet, one row per design × rule.
3. **Collect both reviews.** The AI reviewer's comments with the human's accept/reject on each (`examples/ai_comments.csv`), and what a human reviewer caught on their own (`examples/human_catches.csv`).
4. **Measure (agreement).** Read `agents/agreement.md`. Runs `python3 scripts/evals.py agreement ai.csv human.csv`.
5. **Stop at the human.** Show both numbers, what the AI missed, which issues it gets wrong most, and the sample note. Ask what, if anything, may be claimed outside the team. Draft the sentence; don't publish it.

## Files

- `scripts/evals.py`: `evalset`, `agreement`. Python 3, no dependencies.
- `references/rulebook.json`: Team 01's 12 starter heuristics, so the issue keys line up.
- `references/the-role.md`: what "the designer who models the AI" does, in plain words.
- `examples/`: three designs, the AI's comments and a human's catches (example data).
