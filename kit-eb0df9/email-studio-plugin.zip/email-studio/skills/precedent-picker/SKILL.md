---
name: precedent-picker
description: "Stage 6 · Match + Remix. Choose the approved precedent for each brief: the template the brief names, last year's matching send for sale sets, the letter for founder notes, the brand's grid when a grid is requested, otherwise a hero and module unused in the last 8 sends. Use when planning or before building."
---

# Precedent picker (Stage 6)
Order of authority: brief names a template → use it (rotation off). Sale sets → last year's matching send in the set; vary hero and module across the set. Letter → the approved founder letter. "Feature in a grid" → the brand's tile grid. Else: hero ≠ the 3 sends before and 2 after; module unused for 8 sends; never 3 identical rows in a row; body ground alternates with the previous send.
Dark bodies only where BRAND.md allows them, with precedent. No new elements, ever.

## Lock and remix (Template Remix 625)
Lock what the brief fixes (named template, named rows, product count, sale structure). Remix only the rest, from approved rows.
Output: precedent id + one-line reason per pick, written into the week plan and the decision card.
Manual: Ch. 05 Template Remix 625.
