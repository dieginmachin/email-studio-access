# Chapter 01, in brief: Capacity = Systems × Standards

Source: The Capacity Manual, chapter 01. Use this wording when you explain a result.

**The bottleneck is capacity.** Agencies run out of design capacity before they run out of clients. The obvious fix is headcount. It works for a while. Then each new designer brings their own layer names, their own spacing habits, their own idea of the brand. Reviews get longer. Output per head drops as heads go up.

**The equation.** Capacity = Systems × Standards. Headcount is not a term.
- **Systems** are how work moves: one task per email, one Figma file per brand, statuses that log credits, templates that start every design, AI that drafts inside those templates.
- **Standards** are what good looks like, written down: Email Layers, the 7 point pre export checklist, hard rules per brand. The approved template is the law.

It's multiplication, not addition. A great system with no standards ships fast garbage. Great standards with no system live in one senior head. Either side at zero gives you zero.

**Before you hire, ask two questions.** Is the work written down as a standard? Does it move through a system? If either answer is no, a new hire inherits the chaos.

**Cost per email** = monthly designer cost / (emails per day × working days). Hold the monthly cost still and double the emails per day: the cost per email halves. Emails per day is the only input a system can change.

**Goals versus results.** Keep targets and results apart in your reporting. A goal said out loud is not output delivered.

**Your own baseline.** Pull last month's tasks. Count unique designs, not rows. Divide by business days. That is your team number. Write it down before you change anything.

**Team numbers.** If your task tool can't split output by person (for example because one account sits on most tasks), say so. That gap is a measurement to fix, not a claim to make.
