#!/usr/bin/env python3
"""Capacity Calculator: The Capacity Manual, chapter 01 install.

Reads a task export (ClickUp CSV, or JSON from the ClickUp MCP), counts unique
designs (not rows), divides by business days, and returns the team's designs per
business day and cost per email:

    cost per email = monthly design cost / (designs per business day x working days)

Standard library only. Usage:
    python3 capacity.py tasks.csv [--from 2026-10-01] [--to 2026-10-31] [--monthly-cost 9000]
                        [--done-status complete,closed] [--holidays 2026-11-26,2026-11-27]
                        [--baseline baseline.json] [--save-baseline baseline.json] [--json]
Run with --help for every option.
"""
import argparse, csv, datetime as dt, json, re, sys
from collections import Counter, defaultdict
from pathlib import Path

TITLE_COLS = ["task name", "name", "title", "task", "task title"]
DONE_COLS = ["date done", "date closed", "date_done", "date_closed", "done date", "closed date", "completed", "completed at", "date completed"]
STATUS_COLS = ["status", "task status"]
PEOPLE_COLS = ["assignees", "assignee", "assigned to", "owner"]
LIST_COLS = ["list name", "list", "folder name", "space name"]
DONE_STATUSES = {"complete", "completed", "closed", "done", "approved", "delivered", "sent to client", "client approved"}


def norm_title(t, strip):
    t = re.sub(r"\s+", " ", (t or "").strip().lower())
    for pat in strip:
        t = re.sub(pat, "", t, flags=re.I).strip()
    return t


def parse_date(v):
    """ClickUp exports dates as epoch milliseconds or as text. Accept both."""
    if v is None:
        return None
    if isinstance(v, (int, float)):
        n = float(v)
    else:
        s = str(v).strip()
        if not s:
            return None
        if re.fullmatch(r"\d{10,13}(\.\d+)?", s):
            n = float(s)
        else:
            s = re.sub(r"\s+(at\s+)?\d{1,2}:\d{2}(:\d{2})?\s*(am|pm)?.*$", "", s, flags=re.I)
            for fmt in ("%Y-%m-%d", "%m/%d/%Y", "%m/%d/%y", "%d/%m/%Y", "%A, %B %d %Y", "%A, %B %d, %Y", "%B %d, %Y", "%b %d, %Y", "%Y/%m/%d"):
                try:
                    return dt.datetime.strptime(s, fmt).date()
                except ValueError:
                    pass
            try:
                return dt.datetime.fromisoformat(s.replace("Z", "+00:00")).date()
            except ValueError:
                return None
    if n > 1e11:  # milliseconds
        n /= 1000
    return dt.datetime.fromtimestamp(n, dt.timezone.utc).date()


def pick(headers, wanted, override=None):
    low = {h.lower().strip(): h for h in headers}
    if override:
        if override.lower() in low:
            return low[override.lower()]
        sys.exit(f"Column '{override}' not found. Columns: {', '.join(headers)}")
    for w in wanted:
        if w in low:
            return low[w]
    return None


def load(path):
    p = Path(path)
    text = p.read_text(encoding="utf-8-sig")
    if p.suffix.lower() == ".json" or text.lstrip()[:1] in "[{":
        data = json.loads(text)
        if isinstance(data, dict):
            data = data.get("tasks") or data.get("data") or data.get("items") or []
        rows = []
        for t in data:
            r = dict(t)
            for k in ("assignees", "tags"):
                if isinstance(r.get(k), list):
                    r[k] = ", ".join(a.get("username") or a.get("name") or a.get("email") or str(a) if isinstance(a, dict) else str(a) for a in r[k])
            if isinstance(r.get("status"), dict):
                r["status"] = r["status"].get("status", "")
            if isinstance(r.get("list"), dict):
                r["list"] = r["list"].get("name", "")
            rows.append({k: ("" if v is None else v) for k, v in r.items()})
        return rows
    return list(csv.DictReader(text.splitlines()))


def business_days(a, b, holidays):
    d, n = a, 0
    while d <= b:
        if d.weekday() < 5 and d not in holidays:
            n += 1
        d += dt.timedelta(days=1)
    return n


def analyse(rows, args):
    if not rows:
        sys.exit("The export has no rows.")
    headers = list(rows[0].keys())
    c_title = pick(headers, TITLE_COLS, args.title_col)
    c_done = pick(headers, DONE_COLS, args.date_col)
    c_status = pick(headers, STATUS_COLS, args.status_col)
    c_people = pick(headers, PEOPLE_COLS, args.people_col)
    if not c_title:
        sys.exit(f"No task name column found. Pass --title-col. Columns: {', '.join(headers)}")
    if not c_done and not args.undated_in_window:
        sys.exit(f"No done or closed date column found. Pass --date-col, or --undated-in-window with --from/--to if the tasks were already filtered by done date. Columns: {', '.join(headers)}")
    if args.undated_in_window and not (args.date_from and args.date_to):
        sys.exit("--undated-in-window needs --from and --to: the window the tasks were filtered by.")
    done_status = {s.strip().lower() for s in args.done_status.split(",")} if args.done_status else DONE_STATUSES
    holidays = {parse_date(h) for h in (args.holidays or "").split(",") if h.strip()}
    strip = args.strip or []

    kept, skipped = [], Counter()
    for r in rows:
        title = norm_title(r.get(c_title), strip)
        if not title:
            skipped["no task name"] += 1
            continue
        d = parse_date(r.get(c_done)) if c_done else None
        if not d and args.undated_in_window:
            # Fetched with a done-date filter (e.g. ClickUp MCP date_closed_from/to): ClickUp leaves
            # date_closed empty on "complete"-type statuses, so the window itself is the date.
            d = parse_date(args.date_to)
        if not d:
            skipped["no done date"] += 1
            continue
        if c_status and args.done_status != "any":
            st = str(r.get(c_status, "")).strip().lower()
            if st and st not in done_status:
                skipped[f"status not done ({st})"] += 1
                continue
        kept.append((d, title, str(r.get(c_people, "")).strip() if c_people else ""))
    if not kept:
        sys.exit("No finished tasks with a done date. Check --done-status and --date-col. Skipped: " + json.dumps(skipped))

    # Default window: first to last *new* design. A revision closed later doesn't stretch the window.
    firsts = {}
    for d, t, who in sorted(kept):
        firsts.setdefault(t, d)
    start = parse_date(args.date_from) if args.date_from else min(firsts.values())
    end = parse_date(args.date_to) if args.date_to else max(firsts.values())
    window = [k for k in kept if start <= k[0] <= end]
    skipped["outside the window"] = len(kept) - len(window)

    # Unique designs: first finish date per normalised title. A repeat title is a revision, not a new design.
    first = {}
    for d, t, who in sorted(window):
        if t not in first:
            first[t] = (d, who)
    unique = len(first)
    bdays = business_days(start, end, holidays)
    per_day = unique / bdays if bdays else 0.0

    months = defaultdict(lambda: {"rows": 0, "unique": 0})
    for d, t, who in window:
        months[d.strftime("%Y-%m")]["rows"] += 1
    for t, (d, who) in first.items():
        months[d.strftime("%Y-%m")]["unique"] += 1
    month_rows = []
    for m in sorted(months):
        y, mo = map(int, m.split("-"))
        a = max(start, dt.date(y, mo, 1))
        b = min(end, (dt.date(y + (mo == 12), mo % 12 + 1, 1) - dt.timedelta(days=1)))
        bd = business_days(a, b, holidays)
        month_rows.append({"month": m, "rows": months[m]["rows"], "unique": months[m]["unique"], "business_days": bd,
                           "per_business_day": round(months[m]["unique"] / bd, 2) if bd else None})

    people = Counter()
    for t, (d, who) in first.items():
        for p in [x.strip() for x in re.split(r"[,;]", who) if x.strip()] or ["(unassigned)"]:
            people[p] += 1
    top_share = (people.most_common(1)[0][1] / unique) if people and unique else 0
    per_person_ok = bool(c_people) and len(people) > 1 and top_share < .5 and "(unassigned)" not in dict(people.most_common(1))

    out = {
        "window": {"from": start.isoformat(), "to": end.isoformat(), "business_days": bdays, "holidays_excluded": len([h for h in holidays if h and start <= h <= end and h.weekday() < 5])},
        "rows_in_window": len(window),
        "unique_designs": unique,
        "revisions_or_duplicates": len(window) - unique,
        "designs_per_business_day_team": round(per_day, 2),
        "months": month_rows,
        "columns_used": {"task_name": c_title, "done_date": c_done or ("window (--undated-in-window)" if args.undated_in_window else None), "status": c_status, "assignees": c_people},
        "skipped": {k: v for k, v in skipped.items() if v},
        "people": dict(people.most_common()) if per_person_ok else None,
        "per_person_note": None if per_person_ok else (
            "No assignee column, so this is a team number only." if not c_people else
            f"One account sits on {round(top_share * 100)}% of designs, so per person numbers would mislead. Team number only."),
    }
    if args.monthly_cost:
        wd = args.working_days or (round(bdays / max(1, len(month_rows)), 1) if month_rows else 21)
        cost = args.monthly_cost
        out["cost"] = {
            "monthly_design_cost": cost, "working_days": wd,
            "cost_per_email": round(cost / (per_day * wd), 2) if per_day and wd else None,
            "formula": f"{cost:g} / ({per_day:.2f} x {wd:g})",
            "if_per_day_were": {str(n): round(cost / (n * wd), 2) for n in sorted({max(1, round(per_day)) + k for k in (-2, -1, 0, 1, 2, 5)}) if n > 0},
        }
    if args.baseline and Path(args.baseline).exists():
        base = json.loads(Path(args.baseline).read_text())
        b = base.get("designs_per_business_day_team")
        out["vs_baseline"] = {"baseline_window": base.get("window"), "baseline_per_day": b,
                              "change_per_day": round(per_day - b, 2) if b is not None else None,
                              "note": "Correlation, not proof of cause. Note what else changed in between."}
    return out


def report(o):
    w = o["window"]
    L = [f"# Capacity baseline: {w['from']} to {w['to']}", "",
         f"**{o['unique_designs']} unique designs** in {w['business_days']} business days = **{o['designs_per_business_day_team']} designs per business day, team.**", "",
         f"- Rows in the export window: {o['rows_in_window']} ({o['revisions_or_duplicates']} were repeats of a title: revisions, not new designs)",
         f"- Columns used: {', '.join(f'{k} = {v}' for k, v in o['columns_used'].items() if v)}"]
    if w["holidays_excluded"]:
        L.append(f"- Holidays excluded: {w['holidays_excluded']}")
    if o["skipped"]:
        L.append("- Skipped rows: " + ", ".join(f"{k}: {v}" for k, v in o["skipped"].items()))
    L += ["", "| Month | Rows | Unique designs | Business days | Per business day |", "|---|---:|---:|---:|---:|"]
    L += [f"| {m['month']} | {m['rows']} | {m['unique']} | {m['business_days']} | {m['per_business_day']} |" for m in o["months"]]
    if "cost" in o:
        c = o["cost"]
        L += ["", "## Cost per email", "", f"**{c['cost_per_email']}** = {c['formula']}", "",
              "| Designs per business day | Cost per email |", "|---:|---:|"]
        L += [f"| {n} | {v} |" for n, v in c["if_per_day_were"].items()]
        L += ["", "Cost and working days are set. Designs per day is the only input a system can move."]
    L += ["", "## Per person", "", o["per_person_note"] or "\n".join(f"- {p}: {n}" for p, n in o["people"].items())]
    if "vs_baseline" in o:
        v = o["vs_baseline"]
        L += ["", "## Against your last baseline", "", f"Baseline: {v['baseline_per_day']} per business day ({v['baseline_window']['from']} to {v['baseline_window']['to']}). Change: {v['change_per_day']:+}. {v['note']}"]
    L += ["", "_Team numbers from your own task export. Unique designs by task name, not rows. Results, not goals._"]
    return "\n".join(L)


def main(argv=None):
    ap = argparse.ArgumentParser(description="Count unique designs per business day and cost per email from a task export.")
    ap.add_argument("export", help="ClickUp CSV export, or JSON of tasks (e.g. from the ClickUp MCP)")
    ap.add_argument("--from", dest="date_from", help="Window start, YYYY-MM-DD (default: first done date)")
    ap.add_argument("--to", dest="date_to", help="Window end, YYYY-MM-DD (default: last done date)")
    ap.add_argument("--monthly-cost", type=float, help="Monthly cost of the design team counted in the export")
    ap.add_argument("--working-days", type=float, help="Working days per month for cost per email (default: business days per month in the window)")
    ap.add_argument("--done-status", help="Comma list of statuses that count as finished, or 'any' (default: complete, closed, done, approved, ...)")
    ap.add_argument("--holidays", help="Comma list of YYYY-MM-DD dates to leave out of business days")
    ap.add_argument("--strip", action="append", help="Regex to strip from task names before deduplicating, e.g. ' v\\d+$'. Repeatable.")
    ap.add_argument("--undated-in-window", action="store_true", help="Count tasks with no done date inside --from/--to. Use when the tasks were pulled with a done-date filter (ClickUp MCP leaves date_closed empty on complete statuses). Monthly split is then not available.")
    ap.add_argument("--title-col"); ap.add_argument("--date-col"); ap.add_argument("--status-col"); ap.add_argument("--people-col")
    ap.add_argument("--baseline", help="Compare with a baseline saved by --save-baseline")
    ap.add_argument("--save-baseline", help="Write this run's result as JSON, to compare next time")
    ap.add_argument("--json", action="store_true", help="Print JSON instead of the markdown report")
    args = ap.parse_args(argv)
    o = analyse(load(args.export), args)
    if args.save_baseline:
        Path(args.save_baseline).write_text(json.dumps(o, indent=2))
    print(json.dumps(o, indent=2) if args.json else report(o))


if __name__ == "__main__":
    main()
