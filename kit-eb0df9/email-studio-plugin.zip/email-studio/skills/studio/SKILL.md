---
name: studio
description: "Stages 1 to 9 · Studio. The front door to Diego Garza's Email Studio: explains the 9 stages (Intake, Brand, Library, Layers, Atomic, Match + Remix, Build, Review, Run) and routes to the right skill. Use when someone says 'start a new brand', 'run my week', 'review this email', 'where do I start', 'what can Email Studio do', or isn't sure which email skill to use."
---

# Email Studio

From brand intake to the approved email in Figma, in 9 stages. Each stage is a skill or a small team: lead → maker → reviewer → **a human approves**. The full process is in `references/process.md`.

## Route the request

Ask one question only if the request doesn't say which brand or which email.

| They say | Do this |
|---|---|
| "start a new brand", "onboard <brand>", "set up <brand>" | **New brand.** In Claude Code: `/email-studio:new-brand <Brand>`. Otherwise, in order: `brand-extract` → `rules-sweep` (with `feedback-twice` for repeated notes) → `library-digest` → `email-layers` on 2 or 3 approved emails → optional `atomic-emails`. |
| "run my week", "plan next week", "what's ready" | **The week.** Friday: `week-planner` (or `/email-studio:plan-week <brand> <monday>`). Then per email: `intake-sort` → `rules-sweep` → `copy-template-match` → `precedent-picker` → `figma-reshuffle-build` → `preflight` → `review-deck` (or `/email-studio:run-week <brand> <monday>`). |
| "review this email", "check it", "preflight", "is this ready?" | **Review.** `preflight` (verdict, provenance, decision card). Layer problems: `email-layers`. A review deck: `review-deck`. "Can I trust the AI review?": `model-review-team`. |
| "build", "remix", "make the Tuesday email" | `copy-template-match` → `precedent-picker` → `figma-reshuffle-build` → `preflight`. |
| "what does this brand look like", "get the brand's colours and fonts" | `brand-extract`. |
| "we keep getting the same feedback", "update the rules" | `rules-sweep`, then `feedback-twice` on the notes. |
| "digest the library", "which templates are the law" | `library-digest`. |
| "atomize", "build a parts library" | `atomic-emails`. |
| "where does our time go", "weekly ops report", "sort these briefs" (CSV) | `studio-ops-team`. |
| "what's our capacity", "cost per email", "should we hire" | `capacity-calculator`. |
| "run the queue", "sync approvals" | Only if BRAND.md has a `Hub:` line: `run-queue` / `approval-sync`. Otherwise review in the Figma deck. |

## The 9 stages

| # | Stage | What it does | Skills |
|---|---|---|---|
| 1 | Intake | Reads briefs from Asana or ClickUp, sorts by real status, flags missing fields, date conflicts and AI images | `intake-sort`, `week-planner` |
| 2 | Brand | Extracts the brand's style from its site into BRAND.md, then sweeps comments and client edits into hard and soft rules (The Rules File) | `brand-extract`, `rules-sweep`, `feedback-twice` |
| 3 | Library | Digests approved emails into a template library | `library-digest` |
| 4 | Layers | Audits emails against Email Layers so agents can read them | `email-layers` |
| 5 | Atomic | Cuts approved emails into organisms, molecules and atoms after a reviewer reads the dry run | `atomic-emails` |
| 6 | Match + Remix | Matches brief copy to approved templates, picks the precedent, locks what the brief fixes | `copy-template-match`, `precedent-picker` |
| 7 | Build | Rebuilds the email in Figma from approved rows only, Emailify-ready | `figma-reshuffle-build` |
| 8 | Review | Preflight with the 7 point checklist and a verdict, a review deck, and Model Review to check the checker | `preflight`, `review-deck`, `model-review-team` |
| 9 | Run | Reports where time goes, measures capacity, works a review hub queue | `studio-ops-team`, `capacity-calculator`, `run-queue`, `approval-sync` |

Agents (Claude Code): **sorter** (1, 6), **librarian** (2, 3, 5), **maker** (6, 7), **reviewer** (4, 8), **studio-lead** (9, runs the week).

## Where a brand's files live
`brands/<brand-slug>/` in the folder you work in: `BRAND.md` (The Rules File plus the extracted style guide), `library.json`, `ledger.json`, `weeks/<monday>.json`, `REVISIONS.md`. This folder holds client data: keep it out of any public repo.
In the Claude app there is no shared folder between chats: ask the person to attach BRAND.md and library.json, and give them the updated files back.

## House rules (every stage)
1. **AI drafts. A human approves.** Never post to a client, comment on a task, change a status or write rules without a yes.
2. **No new elements.** Only duplicate, reorder, resize, flip and swap copy or photos from approved rows.
3. **Brief copy only.** The brand's website is the source for photos, product names and colours.
4. **Footers never change.** No AI imagery without the client's approval.
5. **One Figma page per brand.** Never a page per run.
6. **No invented numbers.** Every number names its source. No hit rates, no time saved.

## Needs
A paid Claude plan; the Figma connector (Figma MCP) for stages 3 to 8; Asana or ClickUp for stage 1; Emailify for export; Python 3 for the scripts; Node 18+ for `brand-extract` in Claude Code.

## Suggested routine
Friday: `week-planner` for next week. Monday morning: refresh it. Before every build: `rules-sweep`. Weekly: `library-digest` refresh. Monthly: `studio-ops-team` report and a `capacity-calculator` run against last month's baseline.
