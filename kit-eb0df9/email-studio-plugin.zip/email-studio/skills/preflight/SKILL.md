---
name: preflight
description: "Stage 8 · Review. The Heuristics team plus the Email Studio preflight: checks a built email against written, testable rules (the 7 point pre-export checklist, Email Layers, the studio's hard rules and the brand's own), labels every row Observed, Inferred or Substituted, gives a verdict (Not ready, Unverified, Ready with substitutions, Ready) and writes the decision card. A human accepts or rejects every finding. Use after every build or remix, or for 'preflight', 'check it', 'review this email', 'is this ready?', 'does this follow our rules?', or to write or grow a rulebook."
---

# Preflight (Heuristics team + Email Studio preflight)

From Diego Garza's Studio Of One (Team 01 · Heuristics) and the Email Studio preflight. **Taste does not scale, standards do.** An eye lives in one person. A rule lives in the file, and anyone (or any model) can follow it.

```
lead (this file)  →  rule-maker (agents/rule-maker.md, only to grow the rulebook)  →  reviewer (agents/reviewer.md)  →  HUMAN: accept / reject
```

## House rules
1. **AI drafts. Humans approve.** Never apply a fix, edit a Figma file or change the rulebook without an explicit yes.
2. **A rule you can't check is a wish.** Every rule has a test. `scripts/heuristics.py lint` refuses rules without one.
3. **Evidence or it didn't happen.** Every finding quotes what it saw (a layer path, a value, a link).
4. **Hard rules block export. Soft rules warn.** Report hard fails first.
5. **A missing field is a question, never a pass.**
6. **Never invent numbers** about quality, speed or approval rates.

## Workflow
1. **Pick the rulebook.** `brands/<brand>/rulebook.json` if the brand has one; otherwise `references/email-studio-rulebook.json` (12 starter heuristics + 8 studio rules). Add the brand's Hard and Soft rules from BRAND.md as rules with tests. Lint it: `python3 scripts/heuristics.py lint <rulebook>`.
2. **Get the email into a checkable shape** (`examples/design.json`): with the Figma connector, `create_session`, then `get_metadata` / `get_design_context` on the frame; record layers (name, padding, role, fill, bg, mobile_font), images with alt, links with href, and `checks` for what you actually looked at (`dark_mode_checked`, `columns_stack`, `ai_imagery`, `footer_unchanged`, `no_template_leftovers`, `saved_as_template`). Exported HTML: add `html_kb`. Screenshot only: fill what you can see.
3. **Review (reviewer agent).** Follow `agents/reviewer.md`: `python3 scripts/heuristics.py review design.json <rulebook>`.
4. **Label every row** Observed, Inferred or Substituted against the precedent (see `references/verdict.md`). An unlabeled row is a new element.
5. **Verdict.** NOT READY > UNVERIFIED > READY WITH SUBSTITUTIONS > READY (`references/verdict.md`). Any hard fail or unlabeled row → NOT READY. Any unanswered hard `needs-human`, or links not checked in Emailify → UNVERIFIED.
6. **Decision card.** Write it next to the email (Figma) and as `brands/<brand>/cards/<email>.md`: built from, row table with labels, why, flags.
7. **Stop at the human.** A table: rule · kind · status · evidence · suggested fix · Accept / Reject. End with: "Nothing has been changed. Accept or reject each finding." Rejected findings that repeat mean the rule may be wrong: offer the rule-maker.

## Grow the rulebook
Repeated review notes → `agents/rule-maker.md` (or the `feedback-twice` skill): feedback on two different designs becomes a draft rule with a test; a human says yes before it goes in.

## Files
- `scripts/heuristics.py`: `from-feedback`, `lint`, `review`. Python 3, no dependencies.
- `references/rulebook.json`: the 12 starter heuristics. `references/heuristics-card.md`: the same 12 for people.
- `references/email-studio-rulebook.json`: the 12 plus S01 to S08 (reshuffle-only, brief copy, brand fonts, footer, no template leftovers, saved as template, layout freshness, on-model colour).
- `references/verdict.md`: provenance labels, verdict ladder, the 7 point checklist, render diff, decision card.
- `examples/`: a feedback log and a design file with deliberate problems (example data).

Then: `review-deck` for the human's review. To check how far this review can be trusted: `model-review-team`.
