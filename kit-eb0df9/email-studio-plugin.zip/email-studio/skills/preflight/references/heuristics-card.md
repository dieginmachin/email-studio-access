# The heuristics card: 12 starter rules

From Diego Garza's frameworks. Hard rules block delivery. Soft rules are preferences. Each one has a test, because a rule you can't check is a wish.

| | Rule | Kind | How to check it |
|---|---|---|---|
| H01 | Padding lives on Spacers, set by rule. | hard | Every padding value is in the allowed set |
| H02 | HTML stays under 102 KB, so Gmail doesn't clip it. | hard | Exported file size |
| H03 | Every image has alt text. | hard | No empty alt |
| H04 | Every link is tested and goes somewhere real. | hard | Every href is a full https URL, clicked once |
| H05 | Checked on desktop, mobile and dark mode. | hard | Someone looked, and said so |
| H06 | Columns stack on mobile. | hard | Checked on a phone width |
| H07 | Name things so a stranger, or a model, can follow you. | soft | No "Group 234", "Frame 12", "Rectangle" |
| H08 | CTAs must stand out. | hard | Button vs background contrast 3:1 or more (starting bar) |
| H09 | Body text is readable on a phone. | soft | 14px or more on mobile (starting bar) |
| H10 | Assets come from the brand's website only. | hard | Is every image and logo from the brand's own site? |
| H11 | Prices match the CTA link. | hard | Does every price match the page its CTA opens? |
| H12 | No AI generated product or people imagery unless the client approved it. | hard | Recorded as checked |

Sources: Email Layers, the 7 point pre-export checklist, Template Prepping System SOP v2 hard rules, and the principle "Agents can't read Group 234". The 3:1 and 14px bars are starting values; set your own.
