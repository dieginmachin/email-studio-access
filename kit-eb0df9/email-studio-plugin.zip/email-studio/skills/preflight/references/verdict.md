# Provenance, verdict and the decision card

## Row provenance (every row on the decision card gets one label)
- **Observed**: an exact copy of an approved row (same file or last year's).
- **Inferred**: an approved row reshuffled: flipped, resized, reordered, or a hero replicated layer by layer.
- **Substituted**: the same row with a photo or copy swapped (brief copy, linked variant photo, a material close-up when no photo exists in that colour).
- **No label = a new element.** It fails reshuffle-only (S01). The verdict is NOT READY.

## Verdict
- **NOT READY**: any unlabeled row, any hard-rule failure (font, footer, foreign image, off-brief copy), or an open blocker (for example an AI image waiting for client approval).
- **UNVERIFIED**: no blockers, but evidence is missing: links not checked in Emailify, a `needs-human` hard rule nobody answered, or the HTML export not compared with the Figma frame at 600px.
- **READY WITH SUBSTITUTIONS**: every gate and every piece of evidence passes; Substituted rows remain and are listed.
- **READY**: every gate and every piece of evidence passes, with Observed and Inferred rows only.

Order of precedence: NOT READY > UNVERIFIED > READY WITH SUBSTITUTIONS > READY. Never call an UNVERIFIED email ready.

## The 7 point pre-export checklist (Capacity Manual ch. 08)
Mobile stack (H06) · dark mode (H05) · Gmail clip, HTML under 102 KB (H02) · alt text (H03) · every link tested (H04) · padding on Spacers (H01) · saved as a template (S06).

## Optional render diff
Export the email from Emailify as HTML, render it at 600px, screenshot it, and compare it with the Figma frame exported at 600px. Fix and compare again, up to two times. Export drift (for example an old footer) is a hard failure.

## The decision card ("Why this design")
Written next to each built email, in Figma and as markdown. Shape: `samples/fernhill-outfitters/decision-card.md`.
- Title line: `<email name> · v<n> · <verdict>`
- Built from: the precedent emails and the brief link
- A table: row · source · label
- Why: one line per choice (hero family, module rotation, product capacity)
- Flags: what a human still has to do (links in Emailify, client approvals)
