---
name: week-planner
description: "Stage 1 · Intake. Plan the coming week before Monday: pull the week from Asana or ClickUp, sort readiness, assign a precedent per email, list client questions, and lay out the week map. Use on Fridays or for 'plan next week', 'pre-week', '/email-studio:plan-week'."
---

# Week planner (Stage 1, feeds Stage 9)
Runs intake-sort → rules-sweep → precedent-picker for every send in the week and writes the week plan to `brands/<brand>/weeks/<monday>.json`. If the brand has a review hub (BRAND.md `Hub:` line), seed its map. Drafts one message per client with the open questions; never sent without a human OK.

Suggested routine: Friday morning for the next week, Monday morning refresh.
Output: a table per day (date · title · status · precedent · questions), then the client questions grouped by brand.
Manual: Ch. 13 Capacity math and Black Friday.
