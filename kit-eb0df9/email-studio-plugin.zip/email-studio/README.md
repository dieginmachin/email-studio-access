# Email Studio

Diego Garza's email design process, installed on your own machine. From brand intake to the approved email in Figma, in 9 stages. You run it yourself. AI drafts; a human approves every email.

**Install:** see `INSTALL.md` (about 5 minutes in Claude Code; the Claude app uses the zips).
**Start:** ask Claude "where do I start with Email Studio?" or run `/email-studio:new-brand <Brand>`.

## The 9 stages

| # | Stage | What it does | Skills |
|---|---|---|---|
| 1 | Intake | Reads briefs from Asana or ClickUp, sorts them by real status, flags missing fields, date conflicts and AI images | `intake-sort`, `week-planner` |
| 2 | Brand | Extracts the brand's style from its website, then sweeps comments and client edits into hard and soft rules (The Rules File) | `brand-extract`, `rules-sweep`, `feedback-twice` |
| 3 | Library | Digests approved emails into a template library | `library-digest` |
| 4 | Layers | Audits a Figma email against Email Layers so agents can read it | `email-layers` |
| 5 | Atomic | Cuts approved emails into organisms, molecules and atoms after a reviewer reads the dry run | `atomic-emails` |
| 6 | Match + Remix | Matches brief copy to approved templates, picks the precedent, locks what the brief fixes | `copy-template-match`, `precedent-picker` |
| 7 | Build | Rebuilds the email in Figma from approved rows only, Emailify-ready | `figma-reshuffle-build` |
| 8 | Review | Preflight with the 7 point checklist and a verdict, a review deck, and Model Review to check the checker | `preflight`, `review-deck`, `model-review-team` |
| 9 | Run | Reports where time goes, measures your capacity, works a review hub queue (optional) | `studio-ops-team`, `capacity-calculator`, `run-queue`, `approval-sync` |

Plus `studio`, the front door: it explains the stages and routes "start a new brand", "run my week" and "review this email" to the right skill.

## Agents (Claude Code)
**sorter** (stages 1, 6) · **librarian** (2, 3, 5) · **maker** (6, 7) · **reviewer** (4, 8) · **studio-lead** (9, runs the week).

## Commands (Claude Code)
| Command | Does |
|---|---|
| `/email-studio:new-brand <Brand>` | Stages 2 to 5 for a new brand: extract, The Rules File, Figma page, library, rules sweep, layers audit |
| `/email-studio:plan-week <brand> <monday>` | Plans the week: readiness, a precedent per email, client questions |
| `/email-studio:run-week <brand> <monday>` | Builds the week: match, pick, build, preflight, review deck |
| `/email-studio:run-queue`, `/email-studio:sync` | Only for brands with a review hub on BRAND.md's `Hub:` line |

## House rules
- AI drafts. A human approves. Nothing goes to a client without that OK.
- No new elements: only duplicate, reorder, resize, flip, swap copy and photos from approved rows.
- Brief copy only. The brand's website is the source for photos, names and colours.
- Footers never change. No AI imagery without the client's approval.
- One Figma page per brand. No invented numbers.

## Needs
A paid Claude plan · Figma and the Figma connector · Asana or ClickUp for stage 1 · Emailify for export · Python 3 for the scripts · Node 18+ for `brand-extract` in Claude Code.

## Your brand files
Each brand lives in `brands/<brand>/` in the folder you open Claude Code in: `BRAND.md` (The Rules File + style guide), `library.json`, `ledger.json`, `weeks/`, `REVISIONS.md`. That folder holds client data: keep it out of any public repo. A made-up example brand, Fernhill Outfitters, ships in `samples/fernhill-outfitters/` next to this plugin folder.

The process in full: `PROCESS.md`.
