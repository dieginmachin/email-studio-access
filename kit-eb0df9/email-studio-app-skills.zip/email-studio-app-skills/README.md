# Email Studio: skills for the Claude app

One zip per skill. In the Claude app, turn on code execution and skills, then upload the zips you'll use under Skills (don't unzip them).
Start with `studio.zip`, `brand-extract.zip`, `rules-sweep.zip`, `feedback-twice.zip` and `preflight.zip`.
`run-queue` and `approval-sync` need a review hub that isn't included; skip them.
Full steps: INSTALL.md in the kits zip.
