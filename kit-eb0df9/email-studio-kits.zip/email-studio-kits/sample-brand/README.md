# Sample brand: Fernhill Outfitters (fictional)
What a brand folder looks like after `/email-studio:new-brand` and one run. Fernhill is made up; no real client data.
Real brands live in your local `brands/<brand>/` folder, which git ignores.

- `BRAND.md`: the brand's rules (Hard blocks export, Soft warns), files and PM source.
- `library.json`: approved emails the studio may reuse, digested from Figma.
- `decision-card.md`: the "why this design" card preflight writes next to each built email.
- `week.json`: what `plan-week` produces for one week.
- `fernhill.dembrandt.json`: a made-up dembrandt extraction for the same brand (no real site).
- `BRAND.extracted.md`: what `brand-extract` writes from it: The Rules File, proposed rules, and the style guide.
