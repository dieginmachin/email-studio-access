# Fernhill Outfitters · The Rules File
Files: <year> emails file `<figma file key>` (page 🤖 Email Studio · Fernhill Outfitters) · last year's file `<figma file key>`.
PM: <Asana project id | ClickUp list id> · status field: <name of the status field to sort by>.
Website: https://fernhill.example/ (source for product photos, names and colours).
Hub: <review hub artifact link, or leave empty>
Reviewer: <who approves> · Client contact: <name>.
## Hard (blocks export)
- No new elements: reshuffle approved rows only (Email Studio house rule).
- Brief copy only; product names from linked pages. Website is the source for photos and colours.
- Footer never changes.
- No AI imagery without approval.
- Fonts: <family and weights, with who said it and when>.
## Soft (warns)
- Rhythm: hero ≠ 3 before / 2 after; module unused 8 sends; ≤2 identical rows in a row.
- <add the brand's own taste notes here, each with who and when>
## Proposed (from the site; a human moves each one into Hard or Soft, or deletes it)
- Fonts: Work Sans for headlines and body (extracted from https://fernhill.example/, 2026-09-01; confirm with the client).
- Primary colour #2f4a3a (extracted from https://fernhill.example/, 2026-09-01; confirm with the client).
- CTA button: fill #2f4a3a, text #f4efe6, radius 2px (extracted from https://fernhill.example/, 2026-09-01; confirm with the client).

## Style guide (extracted)
Source: https://fernhill.example/ · extracted 2026-09-01 with dembrandt 0.39.2. These are the website's values. Email clients render less than a browser: check before you treat any of them as a rule.

### Colours
| Role | Hex |
|---|---|
| background | `#f4efe6` |
| text | `#1d1f1c` |
| primary | `#2f4a3a` |
| accent | `#6b7f4e` |

Palette (most used first):

| Hex | Role | Uses | Confidence |
|---|---|---:|---|
| `#f4efe6` | surface | 140 | high |
| `#1d1f1c` | text | 120 | high |
| `#2f4a3a` | primary | 64 | high |
| `#e8e4dd` | surface | 40 | medium |
| `#6b7f4e` | accent | 18 | medium |

CSS variables: `--forest` #2f4a3a · `--cream` #f4efe6 · `--moss` #6b7f4e

### Type
Families (most used first): Work Sans
Google Fonts: Work Sans

| Context | Family | Size | Weight | Line height | Tracking |
|---|---|---|---|---|---|
| display | Work Sans | 48px | 600 | 1.05 | -0.96px |
| heading-2 | Work Sans | 28px | 600 | 1.15 | - |
| body | Work Sans | 16px | 400 | 1.55 | - |
| ui | Work Sans | 14px | 600 | 1 | 0.4px |
| caption | Work Sans | 12px | 400 | 1.4 | 0.6px |

### Components
Buttons:

| Fill | Text | Radius | Padding | Size / weight | Hover fill |
|---|---|---|---|---|---|
| #2f4a3a | #f4efe6 | 2px | 14px 28px | 14px / 600 | #1d1f1c |

Links: #1d1f1c underline, hover #2f4a3a none
Badges: #6b7f4e on #f4efe6, radius 999px
Corner radii (most used first): 2px, 999px
Spacing values: 8px, 16px, 24px, 48px

### Motion
Durations: 0.2s, 0.4s
Easings: `ease-out`
Hover patterns: color-shift
Most inboxes don't play CSS motion. Use this for GIF timing and for the brand's feel, not as a rule.

Breakpoints: 640px, 1024px

Logo: https://fernhill.example/logo.svg
