# 260915 (FH) Fall Fleece · v1 · Ready with substitutions
Built from: 260412 Trail Layers (hero, CTA) + 260503 Rain Shells (pairs). Brief: ClickUp `TASK_ID`.

| Row | Source | Label |
|---|---|---|
| Hero photo, title bottom-left | 260412 hero, photo from the linked product | Observed |
| Intro text | brief copy, verbatim | Observed |
| Pair 1–2 (4 fleeces) | 260503 pair row ×2 | Observed |
| Pair 2 right flat | no flat on the website in Moss; material close-up | Substituted |
| CTA + footer | 260412, unchanged | Observed |

Why: hero family not used in the last 3 sends; pairs unused in 8 sends; 4 products fit two pair rows.
Flags: links not set (set in Emailify before export).
