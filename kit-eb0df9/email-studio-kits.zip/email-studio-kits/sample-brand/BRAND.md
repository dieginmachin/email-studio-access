# Fernhill Outfitters (sample client)
Files: 2026 emails `FIGMA_FILE_KEY` (page 🤖 Email Studio · Fernhill) · 2025 emails `FIGMA_FILE_KEY_2025`.
Hub: (none, review in the Figma deck)
PM: ClickUp list `LIST_ID` · status field: Status.
Website: https://fernhill.example (source for photos, names and colours).
Reviewer: Studio lead · Client contact: Brand manager.
## Hard (blocks export)
- No new elements: reshuffle approved rows only (studio, Jan 2026).
- Brief copy only; product names from linked pages.
- Footer never changes. No AI imagery without approval.
- Fonts: Work Sans 400/600 for all live type (brand manager, Feb 2026).
- Dark backgrounds only for the winter sale set, with precedent (studio, Mar 2026).
## Soft (warns)
- Rhythm: hero ≠ 3 before / 2 after; module unused 8 sends; ≤2 identical rows in a row.
- Hero title on the photo's open space, two weights (brand manager, Apr 2026).
- Product flats on a warm grey tile, filling it (brand manager, Apr 2026).
