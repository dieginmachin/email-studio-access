# <Brand> (<Client>)
Files: <year> emails file `<figma file key>` (page 🤖 Email Studio · <Brand>) · last year's file `<figma file key>`.
PM: <Asana project id | ClickUp list id> · status field: <name of the status field to sort by>.
Website: <url> (source for product photos, names and colours).
Hub: <review hub artifact link, or leave empty>
Reviewer: <who approves> · Client contact: <name>.
## Hard (blocks export)
- No new elements: reshuffle approved rows only (Diego, Nov 6 2026).
- Brief copy only; product names from linked pages. Website is the source for photos and colours.
- Footer never changes.
- No AI imagery without approval.
- Fonts: <family and weights, with who said it and when>.
## Soft (warns)
- Rhythm: hero ≠ 3 before / 2 after; module unused 8 sends; ≤2 identical rows in a row.
- <add the brand's own taste notes here, each with who and when>
