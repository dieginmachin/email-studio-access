# Email Studio · brief → Figma → Emailify

The process the plugin runs for any brand. It holds no client data: each brand's rules, files and run notes live in the local, git-ignored `brands/<brand>/` folder (`BRAND.md`, `library.json`, `ledger.json`, `REVISIONS.md`, `RUNBOOK.md`). See `examples/sample-brand/` for what those files look like.

## Where things live

| What | Where |
|---|---|
| Plugin (skills, agents, commands) | this repo, `plugins/email-studio/` |
| A brand's rules and library | local only: `brands/<brand>/` (created by `/email-studio:new-brand`) |
| Briefs | the brand's Asana project or ClickUp list (named in BRAND.md) |
| Approved emails | the brand's Figma file(s) (named in BRAND.md) |
| Studio output | ONE page per brand in its Figma file: `🤖 Email Studio · <Brand>`, with sections In review / Approved / Superseded. Never a page per run. |

## 1 · Intake and sorting (`intake-sort`)
- Read every open brief. Sort by the brief's real status field (named in BRAND.md), not the board column.
- Ready = copy and links present. Requires edits = brief names a template and lists row-level changes. Flag missing fields, date conflicts and AI images.

## 2 · Rules sweep (`rules-sweep`), before every run
- Read recent task comments, annotations and frames the client edited in Figma. A client-edited frame is the newest spec.
- Write each rule into BRAND.md under **Hard** (blocks export) or **Soft** (warns), with who and when. A note that repeats becomes Hard.

## 3 · Library digest (`library-digest`), per brand, refresh weekly
- List every approved email frame (`YYMMDD (BRAND) Title`). Record row families, hero signature, fonts, fills, buttons, height and last-used date into `library.json`, and the send log into `ledger.json`.

## 4 · Copy mapping (`copy-template-match`)
- Brief copy only, verbatim. Product names from the linked product page. No descriptions unless the brief writes them.
- Match the brief's sections to the template rows that fit them; output a copy → row slot map.

## 5 · Choose layouts (`precedent-picker`)
- A template named in the brief wins. Sale sets use last year's matching send. Founder notes use the letter template.
- Otherwise: hero composition different from the 3 sends before and 2 after; product module unused in the last 8 sends; never 3 identical rows in a row.
- Every pick comes with a one-line reason.

## 6 · Build (`figma-reshuffle-build`)
- Clone the precedent email (keeps Emailify data) or approved rows from other emails in the same file. Never draw new elements.
- Allowed: duplicate, reorder, resize, flip, swap copy and photos. Photos come from the brand's website (`/products/<handle>.json`); on-model only in the linked colour.
- Finishing pass: hero title on the photo's open space, colour from the photo, model photos cropped on the person, flats paired with their model photo and filling the tile.
- A new version moves the old frame to Superseded.

## 7 · Preflight (`preflight`) and verdict
- **Hard:** layer hierarchy, no leftover template images, names = website, no invented copy, prices match, brand fonts, footer unchanged.
- **Soft:** layout freshness, photo colour matches the variant, patch notes checked, STORE twin.
- Every row is labeled **Observed**, **Inferred** or **Substituted**; an unlabeled row is a new element and fails.
- Verdict: **Not ready** beats **Unverified** beats **Ready with substitutions** beats **Ready**. Links can't be set by the agent, so they stay an action item.

## 8 · Review (`review-deck`) and hand-off
- Each email gets its own Figma section plus a 1920×1080 Present-mode deck (← →) with the brief, the why and the flags.
- The reviewer approves or asks for changes; changes come back as a remix with the note.
- Only after the reviewer's OK: set links in Emailify, export at 2x, post to the PM task, move the status. Never post to a client without that OK.

## 9 · Learn from revisions
- When a designer edits a build, diff it against the build, log it in `brands/<brand>/REVISIONS.md`, and promote anything repeated into BRAND.md.

## Optional: review hub and runner
- A brand can have a review hub (a claude.ai artifact with a `reviews` / `jobs` database) named on BRAND.md's `Hub:` line. `approval-sync` and `run-queue` work only for brands that have one.
