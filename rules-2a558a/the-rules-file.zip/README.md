# The Rules File

One file per brand. Hard rules block an email; Soft rules warn. Every rule keeps who said it and when.

1. Copy `brands/_template/BRAND.md` to a folder for one client brand.
2. Run the brand extraction skill (brand-extract.zip) on the brand's website for the colours, type and components.
3. Open the last 30 days of comments and client edits on that brand's emails. Write down every note someone made twice, with who and when. Notes that should stop an email go under Hard; taste notes go under Soft.
4. Compare with the filled sample in `examples/fernhill-outfitters/` (a made-up brand).

Part of Email Studio by Diego Garza.
